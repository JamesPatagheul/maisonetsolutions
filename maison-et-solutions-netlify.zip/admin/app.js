/* Administration Maison et Solutions (HTML + JavaScript, sans PHP).
   Elle modifie content/data.json et les images dans votre dépôt GitHub ;
   Netlify reconstruit ensuite le site automatiquement. */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); }, $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var slugify = function (s) { return String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/œ/g, 'oe').replace(/æ/g, 'ae').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''); };
  var RESERVED = ['index', 'contact', 'merci', '404', 'a-propos', 'blog', 'services', 'realisations', 'admin', 'api', 'assets', 'uploads', 'data'];
  var KEY = 'ms_admin_cfg';
  var cfg = null, data = null, pending = { files: {}, del: [] }, dirty = false, flash = null, repoMedia = null, busy = '';

  /* ---------- Définition des contenus ---------- */
  var pub = ['published', 'Visible sur le site', 'check'], srt = ['sort', 'Ordre (petit = en premier)', 'num'];
  function catOpts() { var o = { 0: 'Sans catégorie' }; (data.categories || []).forEach(function (c) { o[c.id] = c.name; }); return o; }
  function svcSlugOpts(first) { var o = {}; if (first != null) o[''] = first; (data.services || []).forEach(function (s) { o[s.slug] = s.title; }); return o; }
  var E = {
    services: { t: 'Services', s: 'Service', table: 'services', label: 'title', sub: 'grp', help: 'Chaque service a sa propre page, et apparaît dans le grand menu.', f: [
      ['title', 'Titre', 'text'], ['slug', 'Adresse de la page (laisser vide = automatique)', 'slug'], ['grp', 'Groupe dans le menu (ex. Couverture, Charpente, Humidité)', 'text', function () { var g = {}; (data.services || []).forEach(function (s) { if (s.grp) g[s.grp] = s.grp; }); return g; }],
      ['icon', 'Icône', 'icon'], ['summary', 'Résumé court (menu et cartes)', 'text'], ['intro', 'Introduction (haut de la page)', 'textarea'], ['benefits', 'Points forts (un par ligne)', 'textarea'],
      ['body', 'Contenu de la page', 'html'], ['image', 'Image', 'image'], ['cat_id', 'Articles de blog liés', 'select', function () { var o = catOpts(); o[0] = 'Aucune catégorie'; return o; }], ['seo_desc', 'Description pour Google (150 caractères environ)', 'textarea'], pub, srt] },
    articles: { t: 'Articles du blog', s: 'Article', table: 'articles', label: 'title', sub: 'created_at', sortable: false, help: 'Conseils et actualités. Un sommaire est ajouté automatiquement à partir des titres (bouton « Titre »).', f: [
      ['title', 'Titre', 'text'], ['slug', 'Adresse de la page (laisser vide = automatique)', 'slug'], ['category_id', 'Catégorie', 'select', catOpts], ['created_at', 'Date de publication', 'date'],
      ['excerpt', 'Résumé (cartes et Google)', 'textarea'], ['body', 'Article', 'html'], ['image', 'Image principale', 'image'], ['seo_desc', 'Description pour Google', 'textarea'], pub] },
    categories: { t: 'Catégories du blog', s: 'Catégorie', table: 'categories', label: 'name', f: [['name', 'Nom', 'text'], ['slug', 'Adresse (laisser vide = automatique)', 'slug'], srt] },
    pages: { t: 'Pages', s: 'Page', table: 'pages', label: 'title', help: 'Pages libres (mentions légales, partenaires...). Cochez « dans le menu » ou « dans le pied de page » pour les afficher.', f: [
      ['title', 'Titre', 'text'], ['slug', 'Adresse de la page (laisser vide = automatique)', 'slug'], ['body', 'Contenu', 'html'], ['in_menu', 'Afficher dans le menu', 'check'], ['in_footer', 'Afficher dans le pied de page', 'check'], ['seo_desc', 'Description pour Google', 'textarea'], pub, srt] },
    projects: { t: 'Réalisations', s: 'Réalisation', table: 'projects', label: 'title', sub: 'city', help: 'Galerie de chantiers. Ajoutez une photo « avant » pour activer le curseur avant / après.', f: [
      ['title', 'Titre', 'text'], ['city', 'Ville', 'text'], ['service', 'Type de travaux (sert aux filtres)', 'text', function () { var o = {}; (data.services || []).forEach(function (s) { o[s.title] = s.title; }); return o; }], ['year', 'Année', 'text'], ['text', 'Description', 'textarea'], ['image', 'Photo (après)', 'image'], ['image_before', 'Photo avant (facultatif)', 'image'], pub, srt] },
    reviews: { t: 'Avis clients', s: 'Avis', table: 'reviews', label: 'author', sub: 'city', help: 'Ajoutez uniquement de vrais avis de vos clients.', f: [
      ['author', 'Nom du client', 'text'], ['city', 'Ville', 'text'], ['rating', 'Note', 'select', { 5: '5 sur 5', 4: '4 sur 5', 3: '3 sur 5' }], ['text', 'Avis', 'textarea'], ['source', 'Source (ex. Google)', 'text'], pub, srt] },
    faqs: { t: 'Questions fréquentes', s: 'Question', table: 'faqs', label: 'question', sub: 'scope', help: '« Page concernée » vide = question générale (accueil, contact, à propos). Sinon, elle s\'affiche sur la page du service choisi.', f: [
      ['question', 'Question', 'text'], ['answer', 'Réponse', 'textarea'], ['scope', 'Page concernée', 'select', function () { return svcSlugOpts('Générale (toutes les pages)'); }], pub, srt] },
    team: { t: 'Équipe', s: 'Membre', table: 'team', label: 'name', sub: 'role', f: [['name', 'Nom', 'text'], ['role', 'Fonction', 'text'], ['bio', 'Présentation', 'textarea'], ['image', 'Photo', 'image'], pub, srt] },
    stat: { t: 'Chiffres clés', s: 'Chiffre', table: 'items', type: 'stat', label: 'title', sub: 'value', help: 'Les chiffres s\'animent à l\'écran. N\'affichez que des chiffres exacts (ex. 15 ans d\'expérience, 500 chantiers).', f: [['value', 'Chiffre (ex. 15 ou 500+ ou 98%)', 'text'], ['title', 'Légende (ex. années d\'expérience)', 'text'], pub, srt] },
    step: { t: 'Étapes d\'un projet', s: 'Étape', table: 'items', type: 'step', label: 'title', help: 'La frise « Comment ça se passe ? ». Les 4 premières apparaissent aussi sur les pages de services.', f: [['title', 'Titre', 'text'], ['text', 'Description', 'textarea'], pub, srt] },
    why: { t: 'Pourquoi nous choisir', s: 'Atout', table: 'items', type: 'why', label: 'title', f: [['title', 'Titre', 'text'], ['text', 'Description', 'textarea'], ['value', 'Icône', 'icon'], pub, srt] },
    value: { t: 'Valeurs (page À propos)', s: 'Valeur', table: 'items', type: 'value', label: 'title', f: [['title', 'Titre', 'text'], ['text', 'Description', 'textarea'], ['value', 'Icône', 'icon'], pub, srt] },
    label: { t: 'Logos et qualifications', s: 'Logo', table: 'items', type: 'label', label: 'title', help: 'Bandeau défilant sur l\'accueil et blocs « Qualifications » de la page À propos. N\'ajoutez que des labels que vous détenez réellement.', f: [['title', 'Nom', 'text'], ['image', 'Logo (facultatif)', 'image'], pub, srt] }
  };
  var NAV = [['Contenu', ['services', 'articles', 'categories', 'pages']], ['Accueil et À propos', ['projects', 'reviews', 'faqs', 'team', 'stat', 'step', 'why', 'value', 'label']]];
  var INT = ['cat_id', 'category_id', 'rating'];

  /* ---------- GitHub ---------- */
  function gh(path, opt) {
    opt = opt || {};
    return fetch('https://api.github.com/repos/' + cfg.repo + path, Object.assign({}, opt, { headers: Object.assign({ Authorization: 'Bearer ' + cfg.token, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' }, opt.headers || {}) }))
      .then(function (r) {
        if (r.status === 204) return null;
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) { var m = r.status === 401 ? 'Jeton refusé (expiré ou incorrect).' : r.status === 403 || r.status === 404 ? 'Accès refusé ou dépôt introuvable : vérifiez le nom du dépôt et les droits du jeton (Contents : Read and write).' : (j.message || 'Erreur'); throw new Error(m + ' (' + r.status + ')'); }
          return j;
        });
      });
  }
  function b64utf8(b) { var bin = atob(b.replace(/\s/g, '')), a = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new TextDecoder().decode(a); }
  function utf8b64(s) { var a = new TextEncoder().encode(s), bin = ''; for (var i = 0; i < a.length; i += 8192) bin += String.fromCharCode.apply(null, a.subarray(i, i + 8192)); return btoa(bin); }
  function loadData() {
    return gh('/contents/content/data.json?ref=' + encodeURIComponent(cfg.branch)).then(function (r) {
      if (r.content) return b64utf8(r.content);
      return gh('/git/blobs/' + r.sha).then(function (b) { return b64utf8(b.content); });
    }).then(function (t) { data = JSON.parse(t); });
  }
  function publish() {
    busy = 'Publication en cours...'; render();
    var ref = 'heads/' + cfg.branch, base, tree;
    return gh('/git/ref/' + ref).then(function (r) { base = r.object.sha; return gh('/git/commits/' + base); })
      .then(function (c) { tree = c.tree.sha; var items = [], jobs = [];
        jobs.push(gh('/git/blobs', { method: 'POST', body: JSON.stringify({ content: utf8b64(JSON.stringify(data, null, 2)), encoding: 'base64' }) }).then(function (b) { items.push({ path: 'content/data.json', mode: '100644', type: 'blob', sha: b.sha }); }));
        Object.keys(pending.files).forEach(function (p) { jobs.push(gh('/git/blobs', { method: 'POST', body: JSON.stringify({ content: pending.files[p].b64, encoding: 'base64' }) }).then(function (b) { items.push({ path: p, mode: '100644', type: 'blob', sha: b.sha }); })); });
        pending.del.forEach(function (p) { items.push({ path: p, mode: '100644', type: 'blob', sha: null }); });
        return Promise.all(jobs).then(function () { return gh('/git/trees', { method: 'POST', body: JSON.stringify({ base_tree: tree, tree: items }) }); }); })
      .then(function (t) { return gh('/git/commits', { method: 'POST', body: JSON.stringify({ message: 'Mise à jour du site (administration)', tree: t.sha, parents: [base] }) }); })
      .then(function (c) { return gh('/git/refs/' + ref, { method: 'PATCH', body: JSON.stringify({ sha: c.sha }) }); })
      .then(function () { pending = { files: {}, del: [] }; dirty = false; repoMedia = null; flash = [true, 'Publié ! Netlify reconstruit le site : comptez 1 à 2 minutes avant de voir les changements en ligne.']; })
      .catch(function (e) { flash = [false, 'Publication impossible : ' + e.message]; })
      .then(function () { busy = ''; render(); });
  }

  /* ---------- Images ---------- */
  function prep(file) {
    var ext = (file.name.split('.').pop() || '').toLowerCase(); if (ext === 'jpeg') ext = 'jpg';
    var img = ['jpg', 'png', 'webp', 'gif'].indexOf(ext) > -1, vid = ['mp4', 'webm'].indexOf(ext) > -1;
    if (!img && !vid) return Promise.reject(new Error(file.name + ' : formats acceptés jpg, png, webp, gif, mp4, webm.'));
    if (vid && file.size > 25 * 1048576) return Promise.reject(new Error(file.name + ' : vidéo trop lourde (25 Mo maximum, compressez-la).'));
    var p = Promise.resolve({ blob: file, ext: ext });
    if (img && ext !== 'gif') p = createImageBitmap(file).then(function (bmp) {
      var sc = Math.min(1, 2400 / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc);
      var x = c.getContext('2d'), keep = ext === 'png' && file.size < 900 * 1024; if (!keep) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); } x.drawImage(bmp, 0, 0, c.width, c.height);
      return new Promise(function (ok) { c.toBlob(function (b) { ok({ blob: b, ext: keep ? 'png' : 'jpg' }); }, keep ? 'image/png' : 'image/jpeg', 0.86); });
    });
    return p.then(function (r) {
      return new Promise(function (ok, ko) { var fr = new FileReader(); fr.onload = function () { var d = fr.result; var d0 = new Date(); var nm = d0.getFullYear() + ('0' + (d0.getMonth() + 1)).slice(-2) + ('0' + d0.getDate()).slice(-2) + '-' + Math.random().toString(16).slice(2, 10) + '.' + r.ext; ok({ name: nm, orig: file.name, b64: d.split(',')[1], preview: d }); }; fr.onerror = ko; fr.readAsDataURL(r.blob); });
    });
  }
  function addFiles(files) {
    var errs = [], out = [];
    return Promise.all([].map.call(files, function (f) { return prep(f).then(function (x) { pending.files['uploads/' + x.name] = x; dirty = true; out.push('/uploads/' + x.name); }, function (e) { errs.push(e.message); }); })).then(function () { return { paths: out, errs: errs }; });
  }
  function preview(p) { var x = pending.files[String(p).replace(/^\//, '')]; return x ? x.preview : p; }
  function mediaList() {
    var load = repoMedia ? Promise.resolve(repoMedia) : gh('/contents/uploads?ref=' + encodeURIComponent(cfg.branch)).then(function (l) { return l.filter(function (f) { return f.type === 'file' && f.name !== '.gitkeep'; }).map(function (f) { return '/uploads/' + f.name; }); }, function () { return []; });
    return load.then(function (l) { repoMedia = l; var all = Object.keys(pending.files).map(function (k) { return '/' + k; }).concat(l.filter(function (p) { return pending.del.indexOf(p.slice(1)) < 0; })); return all.reverse(); });
  }
  function isVid(p) { return /\.(mp4|webm)$/i.test(p); }
  function thumb(p) { return isVid(p) ? '<video src="' + esc(preview(p)) + '" muted></video>' : '<img src="' + esc(preview(p)) + '" alt="" loading="lazy">'; }
  function picker(kind, cb) {
    var m = document.createElement('div'); m.className = 'pk';
    m.innerHTML = '<div><p><b>Choisissez un fichier</b> ou <input type="file" multiple accept="image/*,video/mp4,video/webm"> <button type="button" class="b s g" data-x>Fermer</button></p><p class="msg ko" hidden></p><div class="mg"><p>Chargement...</p></div></div>';
    document.body.appendChild(m); var g = $('.mg', m), er = $('.msg', m);
    function show() { mediaList().then(function (l) { g.innerHTML = ''; l.forEach(function (p) { if ((kind === 'image' && isVid(p)) || (kind === 'video' && !isVid(p))) return; var d = document.createElement('div'); d.className = 'mi'; d.innerHTML = thumb(p) + '<small>' + esc(p.split('/').pop()) + '</small>'; d.onclick = function () { cb(p); m.remove(); }; g.appendChild(d); }); if (!g.children.length) g.innerHTML = '<p>Aucun fichier. Envoyez-en un ci-dessus.</p>'; }); }
    show();
    $('[data-x]', m).onclick = function () { m.remove(); };
    m.addEventListener('click', function (e) { if (e.target === m) m.remove(); });
    $('input[type=file]', m).onchange = function () { var inp = this; er.hidden = true; addFiles(inp.files).then(function (r) { if (r.errs.length) { er.textContent = r.errs.join(' '); er.hidden = false; } if (r.paths.length === 1 && !r.errs.length) { cb(r.paths[0]); m.remove(); render(true); } else show(); }); };
  }

  /* ---------- Champs ---------- */
  function opts(o) { return typeof o === 'function' ? o() : (o || {}); }
  function field(f, v) {
    var n = f[0], l = f[1], t = f[2], o = f[3], id = 'f_' + n, h = '<div class="fld ' + t + '">';
    if (t === 'check') return h + '<label><input type="checkbox" name="' + n + '"' + (v ? ' checked' : '') + '> ' + esc(l) + '</label></div>';
    h += '<label for="' + id + '">' + esc(l) + '</label>';
    if (t === 'textarea') h += '<textarea id="' + id + '" name="' + n + '" rows="4">' + esc(v) + '</textarea>';
    else if (t === 'html') h += '<div class="ed"><div class="tb"></div><div class="area" contenteditable="true">' + (v || '') + '</div><textarea name="' + n + '" hidden></textarea></div>';
    else if (t === 'image' || t === 'video') h += '<div class="imgf" data-kind="' + t + '"><input id="' + id + '" name="' + n + '" value="' + esc(v) + '" placeholder="Aucun fichier"><div class="pv">' + (v ? (isVid(v) ? '<span>vidéo</span>' : '<img src="' + esc(preview(v)) + '" alt="">') : '') + '</div><button type="button" class="b s" data-pick>Choisir ou envoyer</button><button type="button" class="b s g" data-clear>Retirer</button></div>';
    else if (t === 'num') h += '<input id="' + id + '" type="number" name="' + n + '" value="' + esc(v) + '">';
    else if (t === 'date') h += '<input id="' + id + '" type="date" name="' + n + '" value="' + esc(String(v || '').slice(0, 10)) + '">';
    else if (t === 'icon') { h += '<div class="icons">'; Object.keys(window.ICONS).forEach(function (i) { h += '<label title="' + i + '"><input type="radio" name="' + n + '" value="' + i + '"' + ((v || 'check') === i ? ' checked' : '') + '><span><svg class="ico" viewBox="0 0 48 48"><path d="' + window.ICONS[i] + '"/></svg></span></label>'; }); h += '</div>'; }
    else if (t === 'select') { h += '<select id="' + id + '" name="' + n + '">'; var oo = opts(o); Object.keys(oo).forEach(function (k) { h += '<option value="' + esc(k) + '"' + (String(k) === String(v) ? ' selected' : '') + '>' + esc(oo[k]) + '</option>'; }); h += '</select>'; }
    else { var dl = t === 'text' && o ? ' list="dl_' + n + '"' : ''; h += '<input id="' + id + '" name="' + n + '" value="' + esc(v) + '"' + dl + (t === 'slug' ? ' placeholder="automatique"' : '') + '>'; if (dl) { h += '<datalist id="dl_' + n + '">'; var d2 = opts(o); Object.keys(d2).forEach(function (k) { h += '<option value="' + esc(d2[k]) + '">'; }); h += '</datalist>'; } }
    return h + '</div>';
  }
  function bindForm(form) {
    $$('.imgf', form).forEach(function (w) {
      var inp = $('input', w), pv = $('.pv', w), kind = w.dataset.kind;
      function upd() { pv.innerHTML = inp.value ? (isVid(inp.value) ? '<span>vidéo</span>' : '<img src="' + esc(preview(inp.value)) + '" alt="">') : ''; }
      $('[data-pick]', w).onclick = function () { picker(kind, function (p) { inp.value = p; upd(); dirtyForm = true; }); };
      $('[data-clear]', w).onclick = function () { inp.value = ''; upd(); };
      inp.addEventListener('input', upd);
    });
    $$('.ed', form).forEach(function (ed) {
      var tb = $('.tb', ed), area = $('.area', ed), ta = $('textarea', ed), src = false;
      function cmd(c, v) { area.focus(); document.execCommand(c, false, v || null); }
      [['Gras', 'bold', '<b>G</b>'], ['Italique', 'italic', '<i>I</i>'], ['Titre', 'h2', 'Titre'], ['Sous-titre', 'h3', 'Sous-titre'], ['Paragraphe', 'p', '¶'], ['Liste', 'ul', '• Liste'], ['Liste numérotée', 'ol', '1. Liste'], ['Citation', 'q', '« »'], ['Lien', 'link', 'Lien'], ['Image', 'img', 'Image'], ['Effacer le style', 'clear', 'Effacer'], ['Code HTML', 'src', '&lt;/&gt;']].forEach(function (b) {
        var x = document.createElement('button'); x.type = 'button'; x.title = b[0]; x.innerHTML = b[2];
        x.onclick = function () {
          if (b[1] === 'bold' || b[1] === 'italic') cmd(b[1]); else if (b[1] === 'h2' || b[1] === 'h3' || b[1] === 'p') cmd('formatBlock', b[1]);
          else if (b[1] === 'ul') cmd('insertUnorderedList'); else if (b[1] === 'ol') cmd('insertOrderedList'); else if (b[1] === 'q') cmd('formatBlock', 'blockquote');
          else if (b[1] === 'link') { var u = prompt('Adresse du lien (ex. https://... ou /contact.html)'); if (u) cmd('createLink', u); }
          else if (b[1] === 'img') picker('image', function (p) { area.focus(); document.execCommand('insertImage', false, p); });
          else if (b[1] === 'clear') { cmd('removeFormat'); cmd('formatBlock', 'p'); }
          else { src = !src; if (src) { ta.value = area.innerHTML; ta.hidden = false; ta.rows = 16; ta.style.fontFamily = 'monospace'; area.hidden = true; } else { area.innerHTML = ta.value; ta.hidden = true; area.hidden = false; } }
        };
        tb.appendChild(x);
      });
      ed._get = function () { return src ? ta.value : area.innerHTML; };
      area.addEventListener('paste', function (e) { e.preventDefault(); document.execCommand('insertText', false, (e.clipboardData || window.clipboardData).getData('text/plain')); });
    });
    form.addEventListener('input', function () { dirtyForm = true; });
  }
  var dirtyForm = false;
  function collect(form, fields) {
    var r = {};
    fields.forEach(function (f) {
      var n = f[0], t = f[2], el = form.elements[n], v;
      if (t === 'check') r[n] = el && el.checked ? 1 : 0;
      else if (t === 'num') r[n] = parseInt(el.value, 10) || 0;
      else if (t === 'html') { v = $('.ed [name="' + n + '"]', form).closest('.ed')._get(); r[n] = v.replace(/<(script|style|iframe)[\s\S]*?<\/\1>/gi, '').trim(); }
      else if (t === 'icon') { var c = form.querySelector('[name="' + n + '"]:checked'); r[n] = c ? c.value : 'check'; }
      else if (INT.indexOf(n) > -1) r[n] = parseInt(el.value, 10) || 0;
      else r[n] = String(el.value).replace(/\r/g, '').trim();
    });
    return r;
  }
  function uniqSlug(table, slug, id) { var b = slug || 'sans-titre', s = b, i = 2; while ((data[table] || []).some(function (r) { return r.slug === s && r.id !== id; })) s = b + '-' + (i++); return s; }

  /* ---------- Vues ---------- */
  function rows(en) { var l = (data[en.table] || []).filter(function (r) { return !en.type || r.type === en.type; }); if (en.sortable === false) return l.sort(function (a, b) { return String(b.created_at || '').localeCompare(String(a.created_at || '')) || b.id - a.id; }); return l.sort(function (a, b) { return (a.sort || 0) - (b.sort || 0) || a.id - b.id; }); }
  function shell(title, body, cur) {
    var h = '<input type="checkbox" id="mnt" hidden><label for="mnt" class="burger">Menu</label><aside class="side"><a class="brand" href="#/"><img src="/assets/logo.png" alt=""><span>Administration</span></a><nav><a href="#/"' + (cur === 'dash' ? ' class="on"' : '') + '>Tableau de bord</a><a href="#/leads"' + (cur === 'leads' ? ' class="on"' : '') + '>Demandes</a>';
    NAV.forEach(function (g) { h += '<h4>' + g[0] + '</h4>'; g[1].forEach(function (k) { h += '<a href="#/' + k + '"' + (cur === k ? ' class="on"' : '') + '>' + esc(E[k].t) + '</a>'; }); });
    h += '<h4>Réglages</h4><a href="#/settings"' + (cur === 'settings' ? ' class="on"' : '') + '>Réglages du site</a><a href="#/media"' + (cur === 'media' ? ' class="on"' : '') + '>Images et vidéos</a><a href="#/account"' + (cur === 'account' ? ' class="on"' : '') + '>Connexion</a></nav><div class="sf"><a href="/" target="_blank">Voir le site ↗</a><a href="#/logout">Se déconnecter</a></div></aside>';
    h += '<main class="mainc"><header class="ph"><h1>' + esc(title) + '</h1></header>';
    if (flash) { h += '<p class="msg ' + (flash[0] ? 'ok' : 'ko') + '">' + esc(flash[1]) + '</p>'; flash = null; }
    if (busy) h += '<p class="msg ok">' + esc(busy) + '</p>';
    else if (dirty) h += '<div class="pub"><b>Vous avez des modifications non publiées.</b><button class="b" data-act="publish">Publier sur le site</button></div>';
    return h + body + '</main>';
  }
  function login(err) {
    return '<div class="login"><form class="lg wide" data-login><img src="/assets/logo.png" alt=""><h1>Administration</h1>' + (err ? '<p class="msg ko">' + esc(err) + '</p>' : '') +
      '<label>Dépôt GitHub du site (ex. <code>remi/maison-et-solutions</code>)<input name="repo" value="' + esc(cfg ? cfg.repo : '') + '" required></label><label>Branche<input name="branch" value="' + esc(cfg ? cfg.branch : 'main') + '" required></label>' +
      '<label>Jeton d\'accès GitHub<input type="password" name="token" value="' + esc(cfg ? cfg.token : '') + '" required autocomplete="off"></label><button class="b">Se connecter</button>' +
      '<p><small>Première fois ? Sur github.com : Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token. Choisissez « Only select repositories » (votre site), puis Permissions > Repository permissions > <b>Contents : Read and write</b>. Copiez le jeton ici. Il reste uniquement dans ce navigateur.</small></p></form></div>';
  }
  function view() {
    var h = (location.hash || '#/').replace(/^#\/?/, '').split('/'), p = h[0] || 'dash';
    if (E[p]) return entity(p, h[1], h[2]);
    if (p === 'dash') return dash();
    if (p === 'settings') return settings();
    if (p === 'media') return media();
    if (p === 'leads') return shell('Demandes reçues', '<div class="card"><p>Les demandes de devis, de rappel et les inscriptions arrivent dans <b>Netlify</b> :</p><ol class="todo"><li>Ouvrez <a href="https://app.netlify.com" target="_blank" rel="noopener">app.netlify.com</a> et choisissez votre site.</li><li>Menu <b>Forms</b> : toutes les demandes, avec nom, téléphone et projet. (Si « Forms » est vide, vérifiez que « Form detection » est activé dans Site configuration > Forms.)</li><li>Pour recevoir un e-mail à chaque demande : Forms > <b>Form notifications</b> > Add notification > Email notification.</li></ol></div>', 'leads');
    if (p === 'account') return shell('Connexion', '<div class="card"><p>Dépôt : <b>' + esc(cfg.repo) + '</b> (branche ' + esc(cfg.branch) + ')</p><p class="hlp">Le jeton GitHub est enregistré uniquement dans ce navigateur. N\'utilisez cette administration que sur vos appareils. Pour retirer l\'accès, déconnectez-vous ici et supprimez le jeton sur GitHub.</p><a class="b" href="#/logout">Se déconnecter</a></div>', 'account');
    return dash();
  }
  function dash() {
    var n = function (k) { return (data[k] || []).length; };
    return shell('Tableau de bord', '<div class="kpi"><a href="#/services"><b>' + n('services') + '</b><span>services</span></a><a href="#/articles"><b>' + n('articles') + '</b><span>articles</span></a><a href="#/projects"><b>' + n('projects') + '</b><span>réalisations</span></a><a href="#/reviews"><b>' + n('reviews') + '</b><span>avis</span></a></div>' +
      '<div class="card"><h2>Par où commencer ?</h2><ol class="todo"><li>Renseignez vos coordonnées dans <a href="#/settings">Réglages du site</a> (téléphone, e-mail, adresse du site).</li><li>Envoyez vos photos dans <a href="#/media">Images et vidéos</a>, puis ajoutez-les à vos <a href="#/services">services</a> et <a href="#/projects">réalisations</a>.</li><li>Complétez les <a href="#/pages">pages légales</a> (mentions légales, confidentialité) puis cochez « Visible ».</li><li>Écrivez votre premier <a href="#/articles/new">article de blog</a>.</li><li>Quand vous avez fini : bouton <b>Publier sur le site</b> (il apparaît en haut dès qu\'il y a des modifications).</li></ol></div>' +
      '<div class="card"><h2>Comment ça marche</h2><p class="hlp">Vos modifications restent dans ce navigateur jusqu\'au clic sur « Publier ». Publier envoie tout d\'un coup sur GitHub ; Netlify reconstruit alors le site en HTML (1 à 2 minutes).</p></div>', 'dash');
  }
  function entity(k, a, id) {
    var en = E[k]; id = parseInt(id, 10) || 0;
    if (a === 'new' || a === 'edit') {
      var row = {}; if (a === 'edit') { row = (data[en.table] || []).filter(function (r) { return r.id === id; })[0]; if (!row) { flash = [false, 'Élément introuvable.']; location.hash = '#/' + k; return ''; } }
      else en.f.forEach(function (f) { row[f[0]] = f[2] === 'check' ? (f[0] === 'published' ? 1 : 0) : (f[0] === 'rating' ? 5 : (f[0] === 'created_at' ? new Date().toISOString().slice(0, 10) : '')); });
      var h = '<p><a class="b s g" href="#/' + k + '">← Retour à la liste</a></p><form class="card" data-edit="' + k + '" data-id="' + id + '">'; en.f.forEach(function (f) { h += field(f, row[f[0]]); });
      return shell((a === 'new' ? 'Ajouter : ' : 'Modifier : ') + en.s, h + '<div class="bar"><button class="b">Enregistrer</button> <a class="b g" href="#/' + k + '">Annuler</a></div></form>', k);
    }
    var l = rows(en), h2 = '<p class="hlp">' + esc(en.help || '') + '</p><p><a class="b" href="#/' + k + '/new">+ Ajouter : ' + esc(en.s) + '</a></p>';
    if (!l.length) h2 += '<p class="empty">Rien pour le moment.</p>';
    else { h2 += '<div class="card tbl">'; l.forEach(function (r) { var off = r.published === 0 || r.published === false; h2 += '<div class="row' + (off ? ' off' : '') + '"><div class="rt"><a href="#/' + k + '/edit/' + r.id + '"><b>' + esc(r[en.label]) + '</b></a>' + (en.sub && r[en.sub] ? '<small>' + esc(r[en.sub]) + '</small>' : '') + (off ? '<em>Masqué</em>' : '') + '</div><div class="ra">' + (en.sortable === false ? '' : '<button class="b s g" data-act="move" data-k="' + k + '" data-id="' + r.id + '" data-dir="-1">↑</button><button class="b s g" data-act="move" data-k="' + k + '" data-id="' + r.id + '" data-dir="1">↓</button>') + '<a class="b s g" href="#/' + k + '/edit/' + r.id + '">Modifier</a><button class="b s r" data-act="del" data-k="' + k + '" data-id="' + r.id + '">Supprimer</button></div></div>'; }); h2 += '</div>'; }
    return shell(en.t, h2, k);
  }
  function settings() {
    var h = '<form class="card" data-settings><p class="hlp">Tous les textes, coordonnées et images du site se règlent ici. Enregistrez, puis cliquez sur « Publier sur le site ».</p>';
    window.SETTINGS.forEach(function (g) { h += '<fieldset><legend>' + esc(g.group) + '</legend>'; g.fields.forEach(function (f) { h += field([f[0], f[1], f[2]], data.settings[f[0]]); }); h += '</fieldset>'; });
    return shell('Réglages du site', h + '<div class="bar"><button class="b">Enregistrer</button></div></form>', 'settings');
  }
  var mediaHtml = '<div class="card"><p class="hlp">Envoyez vos photos et vidéos ici (jpg, png, webp, mp4 ; vidéos 25 Mo maximum). Les photos sont réduites automatiquement. Elles sont mises en ligne au clic sur « Publier ».</p><input type="file" id="mfile" multiple accept="image/*,video/mp4,video/webm"> <p class="msg ko" id="merr" hidden></p></div><div class="mg" id="mgrid"><p>Chargement...</p></div>';
  function media() { setTimeout(function () { var g = $('#mgrid'); if (!g) return; mediaList().then(function (l) { g.innerHTML = l.length ? '' : '<p class="empty">Aucun fichier.</p>'; l.forEach(function (p) { var d = document.createElement('div'); d.className = 'mi'; d.innerHTML = thumb(p) + '<small>' + esc(p.split('/').pop()) + '</small><code>' + esc(p) + '</code><button class="b s r" data-act="delmedia" data-p="' + esc(p) + '">Supprimer</button>'; g.appendChild(d); }); }); }, 0); return shell('Images et vidéos', mediaHtml, 'media'); }

  /* ---------- Actions ---------- */
  function renum(list) { list.forEach(function (r, i) { r.sort = i + 1; }); }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b) return; var a = b.dataset.act;
    if (a === 'publish') { publish(); return; }
    if (a === 'move') { var en = E[b.dataset.k], l = rows(en), id = +b.dataset.id, i = l.findIndex(function (r) { return r.id === id; }), j = i + (+b.dataset.dir); if (l[j]) { var t = l[i]; l[i] = l[j]; l[j] = t; renum(l); dirty = true; render(); } }
    if (a === 'del') { if (!confirm('Supprimer définitivement ?')) return; var en2 = E[b.dataset.k], id2 = +b.dataset.id; data[en2.table] = data[en2.table].filter(function (r) { return r.id !== id2; }); if (en2.table === 'categories') data.articles.forEach(function (r) { if (r.category_id === id2) r.category_id = 0; }); dirty = true; render(); }
    if (a === 'delmedia') { if (!confirm('Supprimer ce fichier ? Il disparaîtra des pages qui l\'utilisent.')) return; var p = b.dataset.p.replace(/^\//, ''); if (pending.files[p]) delete pending.files[p]; else pending.del.push(p); dirty = true; render(); }
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.matches('[data-login]')) { e.preventDefault(); cfg = { repo: f.repo.value.trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, ''), branch: f.branch.value.trim(), token: f.token.value.trim() }; busy = ''; $('.lg').classList.add('spin'); loadData().then(function () { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (x) {} location.hash = '#/'; render(); }).catch(function (er) { data = null; $('#app').innerHTML = login(er.message); }); return; }
    if (f.matches('[data-settings]')) { e.preventDefault(); window.SETTINGS.forEach(function (g) { g.fields.forEach(function (fl) { var el = f.elements[fl[0]]; if (el) data.settings[fl[0]] = String(el.value).replace(/\r/g, '').trim(); }); }); data.settings.site_url = (data.settings.site_url || '').replace(/\/+$/, ''); dirty = true; dirtyForm = false; flash = [true, 'Réglages enregistrés. N\'oubliez pas de publier.']; render(); return; }
    if (f.matches('[data-edit]')) {
      e.preventDefault(); var k = f.dataset.edit, en = E[k], id = +f.dataset.id, d = collect(f, en.f), tb = en.table, err = null;
      if (!d[en.label]) err = 'Le champ « titre / nom » est obligatoire.';
      if ('slug' in d && !err) { d.slug = slugify(d.slug || d.title || d.name || ''); if (tb === 'pages' && RESERVED.indexOf(d.slug) > -1) err = 'Cette adresse est réservée par le site, choisissez-en une autre.'; else d.slug = uniqSlug(tb, d.slug, id); }
      if (err) { flash = [false, err]; render(true); return; }
      if (tb === 'articles' && !d.created_at) d.created_at = new Date().toISOString().slice(0, 10);
      if (en.type) d.type = en.type;
      var list = data[tb] = data[tb] || [];
      if (id) { var row = list.filter(function (r) { return r.id === id; })[0]; Object.assign(row, d); }
      else { d.id = list.reduce(function (m, r) { return Math.max(m, r.id); }, 0) + 1; if ('sort' in d && !d.sort) d.sort = list.reduce(function (m, r) { return Math.max(m, r.sort || 0); }, 0) + 1; list.push(d); }
      dirty = true; dirtyForm = false; flash = [true, 'Enregistré. N\'oubliez pas de publier.']; location.hash = '#/' + k; render();
    }
  });
  document.addEventListener('change', function (e) { if (e.target.id === 'mfile') { var er = $('#merr'); er.hidden = true; addFiles(e.target.files).then(function (r) { if (r.errs.length) { er.textContent = r.errs.join(' '); er.hidden = false; } else render(); }); } });
  window.addEventListener('beforeunload', function (e) { if (dirty || dirtyForm) { e.preventDefault(); e.returnValue = ''; } });
  window.addEventListener('hashchange', function () { if (location.hash === '#/logout') { try { localStorage.removeItem(KEY); } catch (x) {} cfg = null; data = null; location.hash = '#/'; render(); return; } dirtyForm = false; render(); });

  function render(keep) {
    var app = $('#app');
    if (!data) { app.innerHTML = login(); return; }
    var y = window.scrollY; app.innerHTML = view(); $$('form', app).forEach(bindForm); if (keep) window.scrollTo(0, y); else window.scrollTo(0, 0);
  }
  try { cfg = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (x) { cfg = null; }
  if (cfg && cfg.token) { $('#app').innerHTML = '<div class="login"><p style="color:#fff">Chargement...</p></div>'; loadData().then(function () { render(); }).catch(function (er) { $('#app').innerHTML = login(er.message); }); } else render();
})();
