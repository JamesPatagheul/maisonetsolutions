<?php
// render.php : génère toutes les pages publiques en HTML statique
require_once __DIR__.'/lib.php';

const RESERVED=['index','contact','merci','404','a-propos','blog','services','realisations','admin','api','assets','uploads','data'];
const ROOFART='<svg class="roofart" viewBox="0 0 800 460" preserveAspectRatio="xMaxYMid meet" aria-hidden="true"><path pathLength="1" d="M20 440 250 215"/><path pathLength="1" d="M250 440V50L470 270 700 40V440"/><path pathLength="1" d="M520 215 700 50"/><path pathLength="1" d="M330 440H780"/><path pathLength="1" d="M740 130h60v300h-60z"/></svg>';

function u_svc($s){ return '/services/'.$s['slug'].'.html'; }
function u_art($a){ return '/blog/'.$a['slug'].'.html'; }
function u_page($p){ return '/'.$p['slug'].'.html'; }
function u_cat($c){ return '/blog/categorie-'.$c['slug'].'.html'; }

function ctx($reset=false){
  static $c=null; if($reset) $c=null; if($c!==null) return $c; $d=db();
  $svc=$d->query("SELECT * FROM services WHERE published=1 ORDER BY sort,id")->fetchAll();
  $groups=[]; foreach($svc as $s) $groups[$s['grp']!==''?$s['grp']:'Services'][]=$s;
  $items=['stat'=>[],'step'=>[],'why'=>[],'value'=>[],'label'=>[]];
  foreach($d->query("SELECT * FROM items WHERE published=1 ORDER BY sort,id") as $i) $items[$i['type']][]=$i;
  $c=['svc'=>$svc,'groups'=>$groups,'items'=>$items,
   'cats'=>$d->query("SELECT * FROM categories ORDER BY sort,id")->fetchAll(),
   'pages'=>$d->query("SELECT * FROM pages WHERE published=1 ORDER BY sort,id")->fetchAll(),
   'projects'=>$d->query("SELECT * FROM projects WHERE published=1 ORDER BY sort,id")->fetchAll(),
   'reviews'=>$d->query("SELECT * FROM reviews WHERE published=1 ORDER BY sort,id")->fetchAll(),
   'faqs'=>$d->query("SELECT * FROM faqs WHERE published=1 ORDER BY sort,id")->fetchAll(),
   'team'=>$d->query("SELECT * FROM team WHERE published=1 ORDER BY sort,id")->fetchAll(),
   'arts'=>$d->query("SELECT a.*,c.name cat_name,c.slug cat_slug FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.published=1 ORDER BY a.created_at DESC,a.id DESC")->fetchAll()];
  return $c;
}

// ---------- Petits composants ----------
function wsplit($t){ $o=''; $i=0; foreach(preg_split('/\s+/',trim($t)) as $w) $o.='<span class="wd"><span style="--i:'.($i++).'">'.e($w).'</span></span> '; return $o; }
function ph($icon='roof',$cls=''){ return '<div class="ph '.e($cls).'" aria-hidden="true"><svg class="ph-i" viewBox="0 0 48 48"><path d="'.(ICONS[$icon]??ICONS['roof']).'"/></svg></div>'; }
function pic($src,$alt,$icon='roof',$cls=''){ return $src ? '<img class="'.e($cls).'" src="'.e($src).'" alt="'.e($alt).'" loading="lazy" decoding="async">' : ph($icon,$cls); }
function sh($title,$sub='',$cls=''){ return '<div class="sh '.$cls.'" data-r><h2>'.e($title).'</h2>'.($sub?'<p>'.e($sub).'</p>':'').'</div>'; }
function paras($t){ $o=''; foreach(preg_split('/\R{2,}/',trim((string)$t)) as $p) if(trim($p)!=='') $o.='<p>'.nl2br(e(trim($p))).'</p>'; return $o; }
function crumbs($list){ $o='<nav class="crumb" aria-label="Fil d\'Ariane"><a href="/">Accueil</a>'; foreach($list as $i=>$c) $o.= ($i===count($list)-1 || !$c[1]) ? '<span>'.e($c[0]).'</span>' : '<a href="'.e($c[1]).'">'.e($c[0]).'</a>'; return $o.'</nav>'; }
function faq_html($list){ if(!$list) return ''; $o='<div class="faq" data-stag>'; foreach($list as $q) $o.='<div class="fq" data-r><h3><button type="button" aria-expanded="false"><span>'.e($q['question']).'</span><i aria-hidden="true"></i></button></h3><div class="fa"><div><p>'.nl2br(e($q['answer'])).'</p></div></div></div>'; return $o.'</div>'; }
function faq_ld($list){ if(!$list) return null; $m=[]; foreach($list as $q) $m[]=['@type'=>'Question','name'=>$q['question'],'acceptedAnswer'=>['@type'=>'Answer','text'=>$q['answer']]]; return ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$m]; }
function stat_html($it){
  $v=trim($it['value']);
  if(preg_match('/^(\D*?)(\d[\d\s]*)(\D*)$/u',$v,$m)) return '<div class="st" data-r><b class="num" data-to="'.e(preg_replace('/\s/','',$m[2])).'" data-pre="'.e($m[1]).'" data-suf="'.e($m[3]).'">'.e($v).'</b><span>'.e($it['title']).'</span></div>';
  return '<div class="st" data-r><b>'.e($v).'</b><span>'.e($it['title']).'</span></div>';
}
function art_card($a,$i=0){
  return '<a class="pc" href="'.u_art($a).'" data-r data-t="'.e(mb_strtolower($a['title'].' '.$a['excerpt'].' '.$a['cat_name'])).'" data-c="'.e($a['cat_slug']).'" data-i="'.$i.'"><div class="pc-i">'.pic($a['image'],$a['title'],'roof').'</div><div class="pc-b"><small><span>'.e($a['cat_name']).'</span><time datetime="'.e(substr($a['created_at'],0,10)).'">'.e(fdate($a['created_at'])).'</time></small><h3>'.e($a['title']).'</h3><p>'.e($a['excerpt']).'</p><b class="more">Lire la suite</b></div></a>';
}
function stars($n){ $n=max(0,min(5,(int)$n)); return '<span class="stars" role="img" aria-label="'.$n.' sur 5">'.str_repeat('★',$n).'<i>'.str_repeat('★',5-$n).'</i></span>'; }
function project_card($p){
  $cap=$p['title'].($p['city']!==''?' - '.$p['city']:'');
  return '<figure class="pj" data-r="zoom" data-svc="'.e(slugify($p['service'])).'"><button type="button" class="pj-b" data-lb data-src="'.e($p['image']).'" data-before="'.e($p['image_before']).'" data-cap="'.e($cap).'" data-txt="'.e($p['text']).'" aria-label="Agrandir : '.e($cap).'">'.pic($p['image'],$p['title'],'roof').($p['image_before']!==''?'<em class="ba-tag">Avant / après</em>':'').'<figcaption><b>'.e($p['title']).'</b><span>'.e(trim($p['city'].($p['year']!==''?' ('.$p['year'].')':''))).'</span></figcaption></button></figure>';
}
function review_card($r){ return '<article class="rc">'.stars($r['rating']).'<p>'.nl2br(e($r['text'])).'</p><footer><b>'.e($r['author']).'</b><span>'.e(trim($r['city'].($r['city']!==''&&$r['source']!==''?', ':'').$r['source'])).'</span></footer></article>'; }
function rating_badge($cls=''){ if(S('rating_value')==='') return ''; return '<a class="rate '.$cls.'" href="/#avis"><span class="stars" aria-hidden="true">★★★★★</span><b>'.e(S('rating_value')).'/5</b>'.(S('rating_count')!==''?'<span>'.e(S('rating_count')).' '.e(S('rating_label')).'</span>':'').'</a>'; }

// ---------- Formulaires ----------
function form_quote($kind='devis',$full=false){
  $groups=array_keys(ctx()['groups']); $ic=[]; foreach(ctx()['groups'] as $g=>$l) $ic[$g]=$l[0]['icon']; ob_start(); ?>
<form class="qf" name="<?= e($kind) ?>" method="post" action="/merci.html" data-netlify="true" data-netlify-honeypot="website" data-qf>
 <input type="hidden" name="form-name" value="<?= e($kind) ?>"><input type="hidden" name="kind" value="<?= e($kind) ?>">
 <div class="qs qs1"><p class="qh">Choisissez votre projet</p>
  <div class="chips"><?php foreach($groups as $g): ?><label class="chip"><input type="radio" name="projet" value="<?= e($g) ?>" required><span><?= ico($ic[$g]) ?><?= e($g) ?></span></label><?php endforeach; ?>
  <label class="chip"><input type="radio" name="projet" value="Autre projet" required><span><?= ico('home') ?>Autre projet</span></label></div>
  <button type="button" class="btn" data-next>Continuer</button></div>
 <div class="qs qs2"><p class="qh">Vos coordonnées <small data-proj></small></p>
  <label>Nom<input name="nom" required autocomplete="name"></label>
  <label>Téléphone<input name="tel" type="tel" required autocomplete="tel"></label>
  <?php if($full): ?><label>E-mail (facultatif)<input name="email" type="email" autocomplete="email"></label><?php endif; ?>
  <label>Créneau de rappel souhaité<select name="creneau"><option>Dès que possible</option><option>10h - 12h</option><option>12h - 14h</option><option>14h - 16h</option><option>16h - 18h</option></select></label>
  <?php if($full): ?><label>Votre message (facultatif)<textarea name="message" rows="3"></textarea></label><?php endif; ?>
  <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
  <div class="qa"><button type="button" class="btn ghost" data-prev>Retour</button><button class="btn">Être rappelé</button></div>
  <p class="legal">Vos données servent uniquement à répondre à votre demande. <?php foreach(ctx()['pages'] as $p) if($p['slug']==='politique-de-confidentialite') echo '<a href="'.u_page($p).'">Confidentialité</a>'; ?></p></div>
 <p class="fmsg" role="status" aria-live="polite"></p>
</form>
<?php return ob_get_clean(); }
function form_callback(){ ob_start(); ?>
<form class="qf cb" name="rappel" method="post" action="/merci.html" data-netlify="true" data-netlify-honeypot="website" data-qf>
 <input type="hidden" name="form-name" value="rappel"><input type="hidden" name="kind" value="rappel"><input type="hidden" name="projet" value="Demande de rappel">
 <label>Nom<input name="nom" required autocomplete="name"></label>
 <label>Téléphone<input name="tel" type="tel" required autocomplete="tel"></label>
 <div class="seg"><label><input type="radio" name="mode" value="Immédiat" checked><span>Être rappelé maintenant</span></label><label><input type="radio" name="mode" value="Plus tard"><span>Être rappelé plus tard</span></label></div>
 <label class="later">Créneau souhaité<select name="creneau"><option>10h - 12h</option><option>12h - 14h</option><option>14h - 16h</option><option>16h - 18h</option></select></label>
 <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
 <button class="btn">Valider</button><p class="legal"><?= e(S('hours')) ?></p><p class="fmsg" role="status" aria-live="polite"></p>
</form>
<?php return ob_get_clean(); }
function form_news(){ return '<form class="nl" name="newsletter" method="post" action="/merci.html" data-netlify="true" data-netlify-honeypot="website" data-qf><input type="hidden" name="form-name" value="newsletter"><input type="hidden" name="kind" value="newsletter"><input type="email" name="email" required placeholder="Votre e-mail" aria-label="Votre e-mail" autocomplete="email"><input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"><button class="btn">S\'abonner</button><p class="fmsg" role="status" aria-live="polite"></p></form>'; }

// ---------- Gabarit commun ----------
function asset($f){ $p=ROOT.'/assets/'.$f; return '/assets/'.$f.'?v='.(is_file($p)?filemtime($p):'1'); }
function layout($o){
  $c=ctx(); $o+=['title'=>'','desc'=>'','path'=>'/','main'=>'','og'=>'','ld'=>[],'cta'=>true,'type'=>'website','noindex'=>false];
  $img=$o['og']!==''?$o['og']:(S('og_image')!==''?S('og_image'):'/assets/logo.png'); $url=base().$o['path'];
  ob_start(); ?>
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($o['title']) ?></title><meta name="description" content="<?= e($o['desc']) ?>">
<?php if($o['noindex']): ?><meta name="robots" content="noindex"><?php endif; ?>
<link rel="canonical" href="<?= e($url) ?>">
<meta property="og:site_name" content="<?= e(S('site_name')) ?>"><meta property="og:locale" content="fr_FR"><meta property="og:type" content="<?= e($o['type']) ?>">
<meta property="og:title" content="<?= e($o['title']) ?>"><meta property="og:description" content="<?= e($o['desc']) ?>"><meta property="og:url" content="<?= e($url) ?>"><meta property="og:image" content="<?= e(starts($img,'http')?$img:base().$img) ?>">
<meta name="twitter:card" content="summary_large_image"><meta name="theme-color" content="#0c1418">
<link rel="icon" href="/assets/logo.png">
<script>document.documentElement.className+=' js';try{if(sessionStorage.i)document.documentElement.className+=' ni'}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:opsz,wght@6..96,500;6..96,600&family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset('style.css') ?>">
<?php foreach($o['ld'] as $l) if($l) echo '<script type="application/ld+json">'.json_encode($l,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG).'</script>'."\n"; ?>
<?= S('head_code') ?>
</head><body>
<div class="intro" aria-hidden="true"><div><?= ROOFART ?><span><?= e(S('site_name')) ?></span></div></div>
<div class="progress" aria-hidden="true"></div>
<?php if(S('topbar_text')!==''): ?><div class="top"><div class="w"><span><?= e(S('topbar_text')) ?></span><?php if(S('topbar_link')!==''): ?><button type="button" data-modal="quote"><?= e(S('topbar_link')) ?></button><?php endif; ?></div></div><?php endif; ?>
<header id="hd"><div class="w bar">
<a class="logo" href="/" aria-label="<?= e(S('site_name')) ?> : accueil"><img src="/assets/logo.png" alt="<?= e(S('site_name')) ?>" width="260" height="173"></a>
<nav class="mn" id="mn" aria-label="Navigation principale">
 <div class="dd"><button type="button" class="dd-t" aria-expanded="false" aria-haspopup="true">Nos services</button>
  <div class="mega"><div class="mega-in w">
   <?php foreach($c['groups'] as $g=>$list): ?><div class="mg"><h3><?= e($g) ?></h3>
    <?php foreach($list as $s): ?><a href="<?= u_svc($s) ?>"><span class="ic"><?= ico($s['icon']) ?></span><span><b><?= e($s['title']) ?></b><small><?= e($s['summary']) ?></small></span></a><?php endforeach; ?></div><?php endforeach; ?>
   <aside class="mp"><h3><?= e(S('topbar_text')?:'Parlons de votre projet') ?></h3><p><?= e(S('hours')) ?></p><button type="button" class="btn" data-modal="quote">Devis gratuit</button><a class="all" href="/services/">Tous nos services</a></aside>
  </div></div></div>
 <?php if($c['projects']): ?><a href="/realisations/">Réalisations</a><?php endif; ?>
 <a href="/blog/">Conseils</a><a href="/a-propos.html">À propos</a>
 <?php foreach($c['pages'] as $p) if($p['in_menu']) echo '<a href="'.u_page($p).'">'.e($p['title']).'</a>'; ?>
 <a href="/contact.html">Contact</a>
</nav>
<div class="act"><a class="tel" href="tel:<?= e(tel()) ?>"><?= ico('phone') ?><span><?= e(S('phone')) ?></span></a><button type="button" class="btn o dk" data-modal="callback">Être rappelé</button><button type="button" class="btn" data-modal="quote">Devis gratuit</button><button type="button" class="burger" id="bg" aria-label="Ouvrir le menu" aria-expanded="false"><i></i><i></i><i></i></button></div>
</div></header>
<main id="main"><?= $o['main'] ?></main>
<?php if($o['cta']): ?><section class="cta"><?= ROOFART ?><div class="w"><div><h2 data-r><?= e(S('cta_title')) ?></h2><p data-r><?= e(S('cta_text')) ?></p></div><div class="cta-b" data-r><button type="button" class="btn dark" data-modal="quote" data-mag>Devis gratuit</button><a class="btn o dk" href="tel:<?= e(tel()) ?>" data-mag><?= e(S('phone')) ?></a></div></div></section><?php endif; ?>
<footer><div class="w"><div class="fg">
 <div class="fb"><img src="/assets/logo.png" alt="<?= e(S('site_name')) ?>" width="200" height="133" loading="lazy"><p><?= e(S('footer_text')) ?></p>
  <p class="fc"><a href="tel:<?= e(tel()) ?>"><?= e(S('phone')) ?></a><a href="mailto:<?= e(S('email')) ?>"><?= e(S('email')) ?></a><?php if(S('address')!=='') echo '<span>'.e(S('address')).'</span>'; ?><span><?= e(S('hours')) ?></span></p>
  <p class="soc"><?php foreach(['facebook'=>'Facebook','instagram'=>'Instagram','linkedin'=>'LinkedIn','youtube'=>'YouTube','tiktok'=>'TikTok'] as $k=>$n) if(S($k)!=='') echo '<a href="'.e(S($k)).'" rel="noopener" target="_blank">'.$n.'</a>'; ?></p></div>
 <?php foreach($c['groups'] as $g=>$list): ?><div><h4><?= e($g) ?></h4><?php foreach($list as $s) echo '<a href="'.u_svc($s).'">'.e($s['title']).'</a>'; ?></div><?php endforeach; ?>
 <div><h4>L'entreprise</h4><a href="/a-propos.html">À propos</a><?php if($c['projects']) echo '<a href="/realisations/">Réalisations</a>'; ?><a href="/blog/">Conseils</a><a href="/contact.html">Contact</a>
  <h4 class="h2nd">Lettre d'information</h4><?= form_news() ?></div>
</div>
<div class="copy"><span>© <?= date('Y') ?> <?= e(S('legal_name')?:S('site_name')) ?><?= S('siret')!==''?' - SIRET '.e(S('siret')):'' ?></span><span class="legal-l"><?php foreach($c['pages'] as $p) if($p['in_footer']) echo '<a href="'.u_page($p).'">'.e($p['title']).'</a>'; ?></span></div></div></footer>
<div class="fab"><a href="tel:<?= e(tel()) ?>"><?= ico('phone') ?>Appeler</a><button type="button" data-modal="quote">Devis gratuit</button></div>
<button type="button" class="fl" data-modal="callback">Être rappelé</button>

<div class="modal" id="m-quote" role="dialog" aria-modal="true" aria-label="Devis gratuit" hidden><div class="mb"><button type="button" class="x" data-close aria-label="Fermer">×</button><h2>Devis gratuit</h2><p class="mi">Un conseiller vous rappelle pour préciser votre projet. <?= e(S('hours')) ?>.</p><?= form_quote('devis') ?></div></div>
<div class="modal" id="m-callback" role="dialog" aria-modal="true" aria-label="Être rappelé" hidden><div class="mb"><button type="button" class="x" data-close aria-label="Fermer">×</button><h2>On vous rappelle</h2><p class="mi">Laissez votre numéro, un conseiller vous contacte. Ou appelez directement le <a href="tel:<?= e(tel()) ?>"><?= e(S('phone')) ?></a>.</p><?= form_callback() ?></div></div>
<div class="lb" id="lb" role="dialog" aria-modal="true" aria-label="Réalisation" hidden><button type="button" class="x" data-close aria-label="Fermer">×</button><button type="button" class="lb-n lb-p" aria-label="Précédente">‹</button><div class="lb-s"></div><button type="button" class="lb-n lb-x" aria-label="Suivante">›</button><p class="lb-c"></p></div>
<script src="<?= asset('main.js') ?>" defer></script>
</body></html>
<?php return ob_get_clean(); }

function org_ld(){
  $o=['@context'=>'https://schema.org','@type'=>'RoofingContractor','name'=>S('site_name'),'url'=>base().'/','image'=>base().'/assets/logo.png','telephone'=>S('phone'),'email'=>S('email'),'areaServed'=>S('zone'),'openingHours'=>S('hours')];
  if(S('address')!=='') $o['address']=['@type'=>'PostalAddress','streetAddress'=>S('address')];
  if(S('rating_value')!=='' && S('rating_count')!=='') $o['aggregateRating']=['@type'=>'AggregateRating','ratingValue'=>str_replace(',','.',S('rating_value')),'reviewCount'=>preg_replace('/\D/','',S('rating_count'))];
  return $o;
}

// ---------- Pages ----------
function p_home(){
  $c=ctx(); $it=$c['items']; $faq=array_values(array_filter($c['faqs'],fn($f)=>$f['scope']===''));
  $mq=[]; foreach($it['label'] as $l) $mq[]=$l; if(!$mq) foreach($c['svc'] as $s) $mq[]=['title'=>$s['title'],'image'=>''];
  ob_start(); ?>
<section class="hero" id="top">
 <div class="hero-bg" data-par="0.22">
  <?php if(S('hero_video')!==''): ?><video autoplay muted loop playsinline preload="metadata"<?= S('hero_image')!==''?' poster="'.e(S('hero_image')).'"':'' ?>><source src="<?= e(S('hero_video')) ?>"></video>
  <?php elseif(S('hero_image')!==''): ?><img src="<?= e(S('hero_image')) ?>" alt="" fetchpriority="high"><?php endif; ?>
  <?= ROOFART ?><canvas class="dust" aria-hidden="true"></canvas></div>
 <div class="hero-shade"></div><div class="spot" aria-hidden="true"></div>
 <div class="w hero-in">
  <div class="hero-copy">
   <?= rating_badge('on-dark') ?>
   <h1><?= wsplit(S('hero_title')) ?></h1><div class="rule"></div>
   <p class="lead" data-r><?= e(S('hero_text')) ?></p>
   <div class="hero-cta" data-r><button type="button" class="btn" data-modal="quote" data-mag><?= e(S('hero_cta')) ?></button><a class="btn o" href="tel:<?= e(tel()) ?>" data-mag><?= e(S('phone')) ?></a></div>
   <ul class="pts" data-r><?php foreach(array_slice(lines(S('hero_points')),0,3) as $p) echo '<li>'.ico('check').e($p).'</li>'; ?></ul>
  </div>
  <div class="qcard" data-r="left"><h2>Un conseiller vous rappelle</h2><p>Gratuit et sans engagement.</p><?= form_quote('devis') ?></div>
 </div>
</section>
<div class="marq" aria-hidden="true"><div class="marq-t"><?php for($k=0;$k<2;$k++) foreach($mq as $l) echo '<span>'.($l['image']?'<img src="'.e($l['image']).'" alt="" loading="lazy">':e($l['title'])).'</span>'; ?></div></div>
<?php if($it['stat']): ?><section class="stats"><div class="w" data-stag><?php foreach($it['stat'] as $s) echo stat_html($s); ?></div></section><?php endif; ?>
<section class="sec"><div class="w"><?= sh('De quoi avez-vous besoin ?','Choisissez le domaine qui correspond à votre projet.') ?>
 <div class="need" data-stag><?php foreach($c['svc'] as $s): ?><a class="nd" href="<?= u_svc($s) ?>" data-r data-tilt><?= ico($s['icon']) ?><h3><?= e($s['title']) ?></h3><p><?= e($s['summary']) ?></p><b class="more">Découvrir</b></a><?php endforeach; ?></div></div></section>
<section class="sec mist about-s"><div class="w split">
 <div class="vis" data-r="mask"><?= pic(S('about_image'),'','home','vis-i') ?><?php if($it['stat']): $f=$it['stat'][0]; ?><div class="chipst"><b><?= e($f['value']) ?></b><span><?= e($f['title']) ?></span></div><?php endif; ?></div>
 <div><h2 data-r><?= e(S('about_title')) ?></h2><div data-r class="txt"><?= paras(S('about_text')) ?></div>
  <ul class="tick" data-r><?php foreach(array_slice($it['why'],0,4) as $w) echo '<li>'.ico('check').e($w['title']).'</li>'; ?></ul>
  <p data-r><a class="btn" href="/a-propos.html">Découvrir l'entreprise</a></p></div></div></section>
<?php if($it['step']): ?><section class="sec dark steps-s"><div class="w steps-w">
 <div class="steps-h"><?= sh('Votre projet, étape par étape','Un parcours clair, avec les mêmes interlocuteurs du premier appel à la fin du chantier.','light') ?><button type="button" class="btn" data-modal="quote" data-r>Démarrer mon projet</button></div>
 <ol class="tl"><?php foreach($it['step'] as $i=>$s) echo '<li data-r="left"><b class="n">'.($i+1).'</b><div><h3>'.e($s['title']).'</h3><p>'.e($s['text']).'</p></div></li>'; ?></ol></div></section><?php endif; ?>
<?php if($c['projects']): ?><section class="sec"><div class="w"><?= sh('Nos réalisations','Quelques chantiers récents.') ?>
 <div class="pjs" data-stag><?php foreach(array_slice($c['projects'],0,6) as $p) echo project_card($p); ?></div>
 <p class="ctr" data-r><a class="btn" href="/realisations/">Toutes nos réalisations</a></p></div></section><?php endif; ?>
<?php if($c['reviews']): ?><section class="sec mist" id="avis"><div class="w"><div class="rv-h"><?= sh('Ils nous ont fait confiance','Les retours de nos clients.') ?><?= rating_badge('on-light') ?></div>
 <div class="rv" data-r><?php foreach($c['reviews'] as $r) echo review_card($r); ?></div>
 <div class="rv-n"><button type="button" class="rv-p" aria-label="Précédent">‹</button><button type="button" class="rv-x" aria-label="Suivant">›</button></div></div></section><?php endif; ?>
<?php if($it['why']): ?><section class="sec"><div class="w"><?= sh('Pourquoi nous choisir ?') ?>
 <div class="why" data-stag><?php foreach($it['why'] as $w) echo '<div class="wy" data-r>'.ico($w['value']?:'check').'<h3>'.e($w['title']).'</h3><p>'.e($w['text']).'</p></div>'; ?></div></div></section><?php endif; ?>
<?php if($faq): ?><section class="sec mist"><div class="w narrow"><?= sh('Questions fréquentes') ?><?= faq_html($faq) ?></div></section><?php endif; ?>
<?php if($c['arts']): ?><section class="sec"><div class="w"><?= sh('Nos conseils','Comprendre sa toiture, sa charpente et l\'humidité.') ?>
 <div class="posts" data-stag><?php foreach(array_slice($c['arts'],0,3) as $i=>$a) echo art_card($a,$i); ?></div><p class="ctr" data-r><a class="btn" href="/blog/">Tous les conseils</a></p></div></section><?php endif; ?>
<?php return layout(['title'=>S('seo_title')!==''?S('seo_title'):S('site_name').' : '.S('tagline'),'desc'=>S('seo_desc')!==''?S('seo_desc'):strip_tags(S('hero_text')),'path'=>'/','main'=>ob_get_clean(),'ld'=>[org_ld(),faq_ld($faq)]]); }

function p_service($s){
  $c=ctx(); [$body,$toc]=add_toc($s['body']); $faq=array_values(array_filter($c['faqs'],fn($f)=>$f['scope']===$s['slug']));
  $ben=lines($s['benefits']); $arts=array_values(array_filter($c['arts'],fn($a)=>(int)$a['category_id']===(int)$s['cat_id'])); $arts=array_slice($arts?:$c['arts'],0,3);
  $pj=array_values(array_filter($c['projects'],fn($p)=>slugify($p['service'])===slugify($s['title'])||slugify($p['service'])===slugify($s['grp'])));
  ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one">
 <div class="hero-copy"><?= crumbs([['Services','/services/'],[$s['grp'],''],[$s['title'],'']]) ?>
 <h1><?= wsplit($s['title']) ?></h1><div class="rule"></div><p class="lead" data-r><?= e($s['intro']) ?></p>
 <div class="hero-cta" data-r><button type="button" class="btn" data-modal="quote" data-mag>Demander un devis gratuit</button><a class="btn o" href="tel:<?= e(tel()) ?>" data-mag><?= e(S('phone')) ?></a></div></div>
 <div class="sv-vis" data-r="zoom"><?= pic($s['image'],$s['title'],$s['icon']) ?></div></div></section>
<section class="sec"><div class="w sv">
 <article class="prose"><?php if(count($toc)>=3): ?><nav class="toc" data-r><b>Sommaire</b><?php foreach($toc as $t) echo '<a href="#'.e($t[0]).'">'.e($t[1]).'</a>'; ?></nav><?php endif; ?><?= $body ?>
  <?php if($ben): ?><h2 id="prestations">Nos prestations</h2><ul class="tick big"><?php foreach($ben as $b) echo '<li>'.ico('check').e($b).'</li>'; ?></ul><?php endif; ?></article>
 <aside class="side"><div class="qcard sticky"><h2>Un conseiller vous rappelle</h2><p>Gratuit et sans engagement.</p><?= form_quote('devis') ?></div></aside></div></section>
<?php if($c['items']['step']): ?><section class="sec dark mini-s"><div class="w"><?= sh('Comment ça se passe ?','','light') ?><ol class="mini" data-stag><?php foreach(array_slice($c['items']['step'],0,4) as $i=>$st) echo '<li data-r><b>'.($i+1).'</b><h3>'.e($st['title']).'</h3><p>'.e($st['text']).'</p></li>'; ?></ol></div></section><?php endif; ?>
<?php if($pj): ?><section class="sec"><div class="w"><?= sh('Nos réalisations') ?><div class="pjs" data-stag><?php foreach(array_slice($pj,0,3) as $p) echo project_card($p); ?></div></div></section><?php endif; ?>
<?php if($faq): ?><section class="sec mist"><div class="w narrow"><?= sh('Questions fréquentes') ?><?= faq_html($faq) ?></div></section><?php endif; ?>
<?php if($arts): ?><section class="sec"><div class="w"><?= sh('Nos conseils') ?><div class="posts" data-stag><?php foreach($arts as $i=>$a) echo art_card($a,$i); ?></div></div></section><?php endif; ?>
<?php return layout(['title'=>$s['title'].' : '.S('site_name'),'desc'=>$s['summary'],'path'=>u_svc($s),'og'=>$s['image'],'main'=>ob_get_clean(),'ld'=>[faq_ld($faq),['@context'=>'https://schema.org','@type'=>'Service','name'=>$s['title'],'description'=>$s['summary'],'provider'=>['@type'=>'RoofingContractor','name'=>S('site_name')],'areaServed'=>S('zone')]]]); }

function p_services(){
  $c=ctx(); ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([['Services','']]) ?><h1><?= wsplit('Nos services') ?></h1><div class="rule"></div><p class="lead" data-r><?= e(S('hero_text')) ?></p></div></div></section>
<?php foreach($c['groups'] as $g=>$list): ?><section class="sec<?= array_search($g,array_keys($c['groups']))%2?' mist':'' ?>"><div class="w"><?= sh($g) ?><div class="need" data-stag><?php foreach($list as $s): ?><a class="nd" href="<?= u_svc($s) ?>" data-r data-tilt><?= ico($s['icon']) ?><h3><?= e($s['title']) ?></h3><p><?= e($s['summary']) ?></p><b class="more">Découvrir</b></a><?php endforeach; ?></div></div></section><?php endforeach; ?>
<?php return layout(['title'=>'Nos services : '.S('site_name'),'desc'=>S('tagline').' en '.S('zone').'.','path'=>'/services/','main'=>ob_get_clean()]); }

function p_projects(){
  $c=ctx(); $f=[]; foreach($c['projects'] as $p) if($p['service']!=='') $f[slugify($p['service'])]=$p['service']; ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([['Réalisations','']]) ?><h1><?= wsplit('Nos réalisations') ?></h1><div class="rule"></div><p class="lead" data-r>Des chantiers menés avec soin, du diagnostic aux finitions.</p></div></div></section>
<section class="sec"><div class="w">
<?php if(count($f)>1): ?><div class="filters" role="group" aria-label="Filtrer par type de travaux"><button type="button" class="on" data-filter="*">Toutes</button><?php foreach($f as $k=>$n) echo '<button type="button" data-filter="'.e($k).'">'.e($n).'</button>'; ?></div><?php endif; ?>
<?php if($c['projects']): ?><div class="pjs big" data-stag data-more="12"><?php foreach($c['projects'] as $p) echo project_card($p); ?></div><p class="ctr"><button type="button" class="btn" id="more-pj" hidden>Plus de réalisations</button></p>
<?php else: ?><p class="empty">Nos réalisations arrivent bientôt.</p><?php endif; ?></div></section>
<?php return layout(['title'=>'Réalisations : '.S('site_name'),'desc'=>'Découvrez nos chantiers de toiture, charpente et traitement de l\'humidité.','path'=>'/realisations/','main'=>ob_get_clean()]); }

function p_blog($cat=null){
  $c=ctx(); $arts=$cat?array_values(array_filter($c['arts'],fn($a)=>$a['cat_slug']===$cat['slug'])):$c['arts']; ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs($cat?[['Conseils','/blog/'],[$cat['name'],'']]:[['Conseils','']]) ?><h1><?= wsplit($cat?$cat['name']:'Nos conseils') ?></h1><div class="rule"></div><p class="lead" data-r>Comprendre sa toiture, sa charpente et l'humidité pour décider sereinement.</p></div></div></section>
<section class="sec"><div class="w">
 <div class="bl-bar"><nav class="tabs" aria-label="Catégories"><a href="/blog/"<?= !$cat?' class="on"':'' ?>>Tous</a><?php foreach($c['cats'] as $k) echo '<a href="'.u_cat($k).'"'.($cat&&$cat['id']==$k['id']?' class="on"':'').'>'.e($k['name']).'</a>'; ?></nav>
 <input type="search" id="bsearch" placeholder="Rechercher un article" aria-label="Rechercher un article"></div>
 <?php if($arts): $first=$arts[0]; ?>
 <a class="feat" href="<?= u_art($first) ?>" data-r><div class="pc-i"><?= pic($first['image'],$first['title'],'roof') ?></div><div class="pc-b"><small><span><?= e($first['cat_name']) ?></span><time><?= e(fdate($first['created_at'])) ?></time></small><h2><?= e($first['title']) ?></h2><p><?= e($first['excerpt']) ?></p><b class="more">Lire l'article</b></div></a>
 <div class="posts" id="posts" data-stag data-more="9"><?php foreach(array_slice($arts,1) as $i=>$a) echo art_card($a,$i); ?></div>
 <p class="ctr"><button type="button" class="btn" id="more-bl" hidden>Plus d'articles</button></p><p class="empty" id="bempty" hidden>Aucun article ne correspond à votre recherche.</p>
 <?php else: ?><p class="empty">Aucun article pour le moment.</p><?php endif; ?></div></section>
<section class="sec mist"><div class="w narrow ctr"><?= sh('Restez informé','Recevez nos conseils d\'entretien.') ?><div class="nlw" data-r><?= form_news() ?></div></div></section>
<?php return layout(['title'=>($cat?$cat['name'].' : Conseils':'Conseils').' : '.S('site_name'),'desc'=>'Conseils sur la toiture, la charpente, les tuiles et l\'humidité.','path'=>$cat?u_cat($cat):'/blog/','main'=>ob_get_clean()]); }

function p_article($a){
  $c=ctx(); [$body,$toc]=add_toc($a['body']); $rel=array_slice(array_values(array_filter($c['arts'],fn($x)=>$x['id']!=$a['id']&&$x['category_id']==$a['category_id'])),0,3);
  if(count($rel)<3) foreach($c['arts'] as $x){ if($x['id']!=$a['id'] && !in_array($x,$rel,true) && count($rel)<3) $rel[]=$x; }
  $url=base().u_art($a); ob_start(); ?>
<section class="hero sm art-h"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([['Conseils','/blog/'],[$a['cat_name']?:'Article','']]) ?><h1><?= wsplit($a['title']) ?></h1><div class="rule"></div><p class="meta" data-r><time datetime="<?= e(substr($a['created_at'],0,10)) ?>"><?= e(fdate($a['created_at'])) ?></time><span><?= read_min($a['body']) ?> min de lecture</span></p></div></div></section>
<section class="sec"><div class="w sv">
 <article class="prose"><?php if($a['image']!=='') echo '<img class="cover" src="'.e($a['image']).'" alt="'.e($a['title']).'">'; ?>
  <?php if(count($toc)>=3): ?><nav class="toc"><b>Sommaire</b><?php foreach($toc as $t) echo '<a href="#'.e($t[0]).'">'.e($t[1]).'</a>'; ?></nav><?php endif; ?><?= $body ?>
  <div class="share"><b>Partager</b><a href="https://www.facebook.com/sharer/sharer.php?u=<?= rawurlencode($url) ?>" target="_blank" rel="noopener">Facebook</a><a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= rawurlencode($url) ?>" target="_blank" rel="noopener">LinkedIn</a><a href="mailto:?subject=<?= rawurlencode($a['title']) ?>&body=<?= rawurlencode($url) ?>">E-mail</a></div></article>
 <aside class="side"><div class="qcard sticky"><h2>Un projet ?</h2><p>Un conseiller vous rappelle, gratuitement.</p><?= form_quote('devis') ?></div></aside></div></section>
<?php if($rel): ?><section class="sec mist"><div class="w"><?= sh('À lire aussi') ?><div class="posts" data-stag><?php foreach($rel as $i=>$x) echo art_card($x,$i); ?></div></div></section><?php endif; ?>
<?php return layout(['title'=>$a['title'].' : '.S('site_name'),'desc'=>$a['seo_desc']!==''?$a['seo_desc']:$a['excerpt'],'path'=>u_art($a),'og'=>$a['image'],'type'=>'article','main'=>ob_get_clean(),'ld'=>[['@context'=>'https://schema.org','@type'=>'BlogPosting','headline'=>$a['title'],'datePublished'=>substr($a['created_at'],0,10),'description'=>$a['excerpt'],'image'=>$a['image']!==''?base().$a['image']:base().'/assets/logo.png','author'=>['@type'=>'Organization','name'=>S('site_name')],'publisher'=>['@type'=>'Organization','name'=>S('site_name')]]]]); }

function p_about(){
  $c=ctx(); $it=$c['items']; ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([['À propos','']]) ?><h1><?= wsplit('Qui sommes-nous ?') ?></h1><div class="rule"></div><p class="lead" data-r><?= e(S('tagline')) ?> en <?= e(S('zone')) ?>.</p></div></div></section>
<section class="sec"><div class="w split"><div class="vis" data-r="mask"><?= pic(S('about_image'),'','home','vis-i') ?></div><div><h2 data-r><?= e(S('about_title')) ?></h2><div data-r class="txt"><?= paras(S('about_text')) ?></div><p data-r><button type="button" class="btn" data-modal="quote">Parler de mon projet</button></p></div></div></section>
<?php if($it['value']): ?><section class="sec mist"><div class="w"><?= sh('Nos valeurs') ?><div class="why" data-stag><?php foreach($it['value'] as $w) echo '<div class="wy" data-r>'.ico($w['value']?:'check').'<h3>'.e($w['title']).'</h3><p>'.e($w['text']).'</p></div>'; ?></div></div></section><?php endif; ?>
<?php if($it['stat']): ?><section class="stats dk"><div class="w" data-stag><?php foreach($it['stat'] as $s) echo stat_html($s); ?></div></section><?php endif; ?>
<?php if($c['team']): ?><section class="sec"><div class="w"><?= sh('L\'équipe') ?><div class="team" data-stag><?php foreach($c['team'] as $m): ?><article class="tm" data-r><div class="tm-i"><?= pic($m['image'],$m['name'],'user') ?></div><h3><?= e($m['name']) ?></h3><b><?= e($m['role']) ?></b><?php if($m['bio']!=='') echo '<p>'.e($m['bio']).'</p>'; ?></article><?php endforeach; ?></div></div></section><?php endif; ?>
<?php if($it['label']): ?><section class="sec mist"><div class="w"><?= sh('Qualifications et partenaires') ?><div class="labels" data-stag><?php foreach($it['label'] as $l) echo '<div class="lbl" data-r>'.($l['image']?'<img src="'.e($l['image']).'" alt="'.e($l['title']).'" loading="lazy">':'').'<span>'.e($l['title']).'</span></div>'; ?></div></div></section><?php endif; ?>
<section class="sec<?= $it['label']?'':' mist' ?>"><div class="w narrow"><?= sh('Fiche d\'identité') ?><dl class="idc" data-r>
 <?php foreach([['Entreprise',S('legal_name')?:S('site_name')],['SIRET',S('siret')],['Adresse',S('address')],['Zone d\'intervention',S('zone')],['Horaires',S('hours')],['Téléphone',S('phone')],['E-mail',S('email')]] as $r) if($r[1]!=='') echo '<div><dt>'.e($r[0]).'</dt><dd>'.e($r[1]).'</dd></div>'; ?></dl></div></section>
<?php if($c['reviews']): ?><section class="sec mist"><div class="w"><?= sh('Ils nous ont fait confiance') ?><div class="rv" data-r><?php foreach($c['reviews'] as $r) echo review_card($r); ?></div><div class="rv-n"><button type="button" class="rv-p" aria-label="Précédent">‹</button><button type="button" class="rv-x" aria-label="Suivant">›</button></div></div></section><?php endif; ?>
<?php return layout(['title'=>'À propos : '.S('site_name'),'desc'=>S('about_title').'. '.S('tagline').'.','path'=>'/a-propos.html','main'=>ob_get_clean()]); }

function p_contact(){
  ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([['Contact','']]) ?><h1><?= wsplit('Parlons de votre projet') ?></h1><div class="rule"></div><p class="lead" data-r>Décrivez-nous votre besoin : un conseiller vous rappelle au créneau de votre choix.</p></div></div></section>
<section class="sec"><div class="w split top">
 <div><div class="cinfo" data-stag>
  <a href="tel:<?= e(tel()) ?>" data-r><?= ico('phone') ?><span><small>Téléphone</small><b><?= e(S('phone')) ?></b></span></a>
  <a href="mailto:<?= e(S('email')) ?>" data-r><?= ico('home') ?><span><small>E-mail</small><b><?= e(S('email')) ?></b></span></a>
  <div data-r><?= ico('clock') ?><span><small>Horaires</small><b><?= e(S('hours')) ?></b></span></div>
  <div data-r><?= ico('roof') ?><span><small>Zone d'intervention</small><b><?= e(S('zone')) ?></b></span></div>
  <?php if(S('address')!==''): ?><a href="https://www.google.com/maps/search/?api=1&query=<?= rawurlencode(S('address')) ?>" target="_blank" rel="noopener" data-r><?= ico('search') ?><span><small>Adresse</small><b><?= e(S('address')) ?></b></span></a><?php endif; ?></div></div>
 <div class="qcard" data-r="left"><h2>Votre demande</h2><p>Simple, rapide et gratuit.</p><?= form_quote('contact',true) ?></div></div></section>
<?php return layout(['title'=>'Contact : '.S('site_name'),'desc'=>'Contactez '.S('site_name').' pour un diagnostic et un devis.','path'=>'/contact.html','main'=>ob_get_clean(),'cta'=>false]); }

function p_page($p){
  [$body,$toc]=add_toc($p['body']); ob_start(); ?>
<section class="hero sm"><div class="hero-bg"><?= ROOFART ?></div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><?= crumbs([[$p['title'],'']]) ?><h1><?= wsplit($p['title']) ?></h1><div class="rule"></div></div></div></section>
<section class="sec"><div class="w"><article class="prose solo"><?= $body ?></article></div></section>
<?php return layout(['title'=>$p['title'].' : '.S('site_name'),'desc'=>$p['seo_desc']!==''?$p['seo_desc']:$p['title'],'path'=>u_page($p),'main'=>ob_get_clean()]); }

function p_simple($t,$msg,$path,$noindex=true){
  return layout(['title'=>$t.' : '.S('site_name'),'desc'=>$t,'path'=>$path,'noindex'=>$noindex,'cta'=>false,'main'=>'<section class="hero sm"><div class="hero-bg">'.ROOFART.'</div><div class="hero-shade"></div><div class="w hero-in one"><div class="hero-copy"><h1>'.wsplit($t).'</h1><div class="rule"></div><p class="lead" data-r>'.e($msg).'</p><p data-r><a class="btn" href="/">Retour à l\'accueil</a></p></div></div></section>']);
}

// ---------- Génération ----------
function build_all(){
  ctx(true); S_clear(); $c=ctx(); $o=[];
  $o['index.html']=p_home(); $o['services/index.html']=p_services();
  foreach($c['svc'] as $s) $o['services/'.$s['slug'].'.html']=p_service($s);
  $o['realisations/index.html']=p_projects(); $o['blog/index.html']=p_blog();
  foreach($c['cats'] as $k) $o['blog/categorie-'.$k['slug'].'.html']=p_blog($k);
  foreach($c['arts'] as $a) $o['blog/'.$a['slug'].'.html']=p_article($a);
  foreach($c['pages'] as $p) if(!in_array($p['slug'],RESERVED,true)) $o[$p['slug'].'.html']=p_page($p);
  $o['a-propos.html']=p_about(); $o['contact.html']=p_contact();
  $o['merci.html']=p_simple('Merci !','Nous avons bien reçu votre demande et nous vous rappelons rapidement.','/merci.html');
  $o['404.html']=p_simple('Page introuvable','La page que vous cherchez n\'existe pas ou a été déplacée.','/404.html');
  $u=[]; foreach($o as $p=>$h){ if($p==='merci.html'||$p==='404.html') continue; $u[]='/'.preg_replace('#index\.html$#','',$p); }
  $o['sitemap.xml']='<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'.implode('',array_map(fn($x)=>'<url><loc>'.e(base().$x).'</loc></url>',$u)).'</urlset>';
  $o['robots.txt']="User-agent: *\nDisallow: /admin/\nSitemap: ".base()."/sitemap.xml\n";
  $out=defined('OUT')?OUT:ROOT; $man=ROOT.'/data/gen.json'; $old=(!defined('OUT')&&is_file($man))?(json_decode(file_get_contents($man),true)?:[]):[]; $err=[];
  foreach($o as $p=>$h){ $f=$out.'/'.$p; if(!is_dir(dirname($f))) @mkdir(dirname($f),0755,true); if(@file_put_contents($f,$h)===false) $err[]=$p; }
  foreach($old as $p) if(!isset($o[$p]) && is_file($out.'/'.$p)) @unlink($out.'/'.$p);
  if(!defined('OUT')) @file_put_contents($man,json_encode(array_keys($o)));
  return $err;
}
