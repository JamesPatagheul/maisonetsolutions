<?php
// lib.php : cœur du site (base de données, réglages, outils communs)
if(!defined('ROOT')) define('ROOT', dirname(__DIR__));
date_default_timezone_set('Europe/Paris');

if (!function_exists('mb_substr'))     { function mb_substr($s,$a,$n=null){ return $n===null?substr($s,$a):substr($s,$a,$n); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($s){ return strtolower($s); } }
if (!function_exists('mb_strlen'))     { function mb_strlen($s){ return strlen($s); } }

function starts($s,$p){ return strncmp((string)$s,$p,strlen($p))===0; }
function e($s){ return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8'); }
function slugify($s){
  $m=['à'=>'a','â'=>'a','ä'=>'a','á'=>'a','ã'=>'a','å'=>'a','ç'=>'c','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ñ'=>'n','ó'=>'o','ò'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y','œ'=>'oe','æ'=>'ae',
     'À'=>'a','Â'=>'a','Ä'=>'a','Ç'=>'c','É'=>'e','È'=>'e','Ê'=>'e','Ë'=>'e','Î'=>'i','Ï'=>'i','Ô'=>'o','Ö'=>'o','Ù'=>'u','Û'=>'u','Ü'=>'u','Œ'=>'oe','’'=>'','\''=>''];
  $s=strtolower(strtr((string)$s,$m)); $s=trim(preg_replace('/[^a-z0-9]+/','-',$s),'-');
  return $s===''?'page':substr($s,0,80);
}
function lines($t){ return array_values(array_filter(array_map('trim',preg_split('/\R/',(string)$t)),'strlen')); }
function fdate($d){ $m=['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre']; $t=strtotime($d); return date('j',$t).' '.$m[(int)date('n',$t)-1].' '.date('Y',$t); }

// ---------- Icônes (viewBox 48) ----------
const ICONS=[
 'roof'=>'M4 26 24 8l20 18M10 22v18h28V22M20 40V28h8v12',
 'frame'=>'M4 38 24 10l20 28zM4 38h40M24 10v28M14 24l10 14 10-14',
 'beam'=>'M6 14h36v8H6zM6 30h36v8H6zM14 22v8M34 22v8',
 'tiles'=>'M6 14h36M6 24h36M6 34h36M14 14v10M30 14v10M22 24v10M38 24v10M14 34v6M30 34v6',
 'drop'=>'M24 6S10 22 10 31a14 14 0 0 0 28 0C38 22 24 6 24 6z',
 'shield'=>'M24 5 8 11v12c0 10 7 17 16 20 9-3 16-10 16-20V11zM17 24l5 5 9-10',
 'tools'=>'M10 38l16-16M30 8a8 8 0 0 0-8 10L8 32a3 3 0 0 0 4 4l14-14a8 8 0 0 0 10-8l-5 5-5-1-1-5z',
 'spray'=>'M16 6h12v8H16zM22 14v6M12 22h20v20H12zM18 30h8',
 'search'=>'M21 9a12 12 0 1 0 0 24 12 12 0 0 0 0-24zM30 30l12 12',
 'sun'=>'M24 16a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM24 4v6M24 38v6M4 24h6M38 24h6M10 10l4 4M34 34l4 4M10 38l4-4M34 14l4-4',
 'home'=>'M6 22 24 6l18 16M12 20v22h24V20M20 42V30h8v12',
 'leaf'=>'M8 40C8 20 20 8 42 8c0 22-12 34-30 34M8 40l18-18',
 'layers'=>'M24 6 42 15 24 24 6 15zM6 24l18 9 18-9M6 33l18 9 18-9',
 'wind'=>'M6 18h22a5 5 0 1 0-5-5M6 26h30a5 5 0 1 1-5 5M6 34h14',
 'user'=>'M24 8a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM8 42c0-9 7-15 16-15s16 6 16 15',
 'clock'=>'M24 6a18 18 0 1 0 0 36 18 18 0 0 0 0-36zM24 14v11l8 5',
 'check'=>'M8 25l11 11L40 12',
 'phone'=>'M12 6h8l3 10-5 3a24 24 0 0 0 11 11l3-5 10 3v8a4 4 0 0 1-4 4C21 40 8 27 8 10a4 4 0 0 1 4-4z',
];
function ico($n,$c=''){ $p=ICONS[$n]??ICONS['roof']; return '<svg class="ico '.e($c).'" viewBox="0 0 48 48" aria-hidden="true"><path d="'.$p.'"/></svg>'; }

// ---------- Base de données ----------
function db(){
  static $db=null; if($db) return $db;
  $f=getenv('MS_DB')?:ROOT.'/data/site.db'; if(!is_dir(dirname($f))) @mkdir(dirname($f),0755,true);
  $db=new PDO('sqlite:'.$f);
  $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
  schema($db);
  if(!getenv('MS_NOSEED') && !$db->query("SELECT COUNT(*) FROM users")->fetchColumn()){ require_once __DIR__.'/seed.php'; seed($db); }
  return $db;
}
function schema($d){
  $d->exec("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");
  $d->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT UNIQUE,hash TEXT)");
  $d->exec("CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY,name TEXT,slug TEXT UNIQUE,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS services(id INTEGER PRIMARY KEY,title TEXT,slug TEXT UNIQUE,grp TEXT,icon TEXT DEFAULT 'roof',summary TEXT,intro TEXT,body TEXT,benefits TEXT,image TEXT,cat_id INTEGER DEFAULT 0,seo_desc TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY,title TEXT,slug TEXT UNIQUE,category_id INTEGER DEFAULT 0,excerpt TEXT,body TEXT,image TEXT,seo_desc TEXT,published INTEGER DEFAULT 1,created_at TEXT)");
  $d->exec("CREATE TABLE IF NOT EXISTS pages(id INTEGER PRIMARY KEY,title TEXT,slug TEXT UNIQUE,body TEXT,in_menu INTEGER DEFAULT 0,in_footer INTEGER DEFAULT 0,seo_desc TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,title TEXT,city TEXT,service TEXT,text TEXT,image TEXT,image_before TEXT,year TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,author TEXT,city TEXT,text TEXT,rating INTEGER DEFAULT 5,source TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS faqs(id INTEGER PRIMARY KEY,question TEXT,answer TEXT,scope TEXT DEFAULT '',published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS team(id INTEGER PRIMARY KEY,name TEXT,role TEXT,bio TEXT,image TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,type TEXT,title TEXT,text TEXT,value TEXT,image TEXT,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0)");
  $d->exec("CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY,kind TEXT,name TEXT,phone TEXT,email TEXT,project TEXT,slot TEXT,message TEXT,status TEXT DEFAULT 'nouveau',note TEXT,ip TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
  $d->exec("CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY,path TEXT,name TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
}

// ---------- Réglages modifiables dans l'administration ----------
function setting_defs(){ return [
 'Entreprise'=>[
  ['site_name','Nom de l\'entreprise','text','Maison et Solutions'],
  ['tagline','Slogan (pied de page)','text','Toiture, charpente, tuiles et humidité'],
  ['phone','Téléphone','text','01 00 00 00 00'],
  ['email','E-mail de contact','text','contact@exemple.fr'],
  ['notify_email','E-mail qui reçoit les demandes (si différent)','text',''],
  ['zone','Zone d\'intervention','text','Île-de-France'],
  ['address','Adresse (facultatif)','text',''],
  ['hours','Horaires','text','Du lundi au samedi, de 9h à 19h'],
  ['legal_name','Raison sociale (page À propos)','text',''],
  ['siret','SIRET (page À propos)','text',''],
 ],
 'Page d\'accueil'=>[
  ['topbar_text','Bandeau du haut : texte','text','Diagnostic de votre toiture et devis gratuits'],
  ['topbar_link','Bandeau du haut : texte du lien','text','Prendre rendez-vous'],
  ['hero_title','Titre principal','text','Une maison saine commence par son toit.'],
  ['hero_text','Texte sous le titre','textarea','Toiture, charpente, tuiles et traitement de l\'humidité : un savoir-faire exigeant pour protéger durablement votre patrimoine.'],
  ['hero_cta','Texte du bouton principal','text','Demander un devis gratuit'],
  ['hero_points','Trois points sous le titre (un par ligne)','textarea',"Diagnostic gratuit à domicile\nDevis détaillé et sans engagement\nUn interlocuteur unique du début à la fin"],
  ['hero_image','Image de fond du haut de page (facultatif)','image',''],
  ['hero_video','Vidéo de fond, mp4 (facultatif)','video',''],
  ['rating_value','Note affichée, ex. 4,9 (vide = masquée)','text',''],
  ['rating_count','Nombre d\'avis, ex. 120','text',''],
  ['rating_label','Source des avis','text','avis Google'],
  ['about_title','Bloc « Qui sommes-nous » : titre','text','Un savoir-faire au service de votre maison'],
  ['about_text','Bloc « Qui sommes-nous » : texte (une ligne vide entre paragraphes)','textarea',"Nous accompagnons les propriétaires dans l'entretien et la rénovation de leur toiture, de leur charpente et dans le traitement de l'humidité.\n\nNotre approche : un diagnostic précis, des solutions adaptées à votre maison et des finitions soignées."],
  ['about_image','Bloc « Qui sommes-nous » : image (facultatif)','image',''],
  ['cta_title','Bandeau final : titre','text','Un projet ? Parlons-en.'],
  ['cta_text','Bandeau final : texte','text','Un conseiller vous rappelle au créneau de votre choix.'],
 ],
 'Pied de page et réseaux'=>[
  ['footer_text','Texte du pied de page','textarea','Toiture, charpente, tuiles et traitement de l\'humidité.'],
  ['facebook','Facebook (adresse complète)','text',''],
  ['instagram','Instagram (adresse complète)','text',''],
  ['linkedin','LinkedIn (adresse complète)','text',''],
  ['youtube','YouTube (adresse complète)','text',''],
  ['tiktok','TikTok (adresse complète)','text',''],
 ],
 'Site et référencement'=>[
  ['site_url','Adresse du site (sans / à la fin)','text','https://www.exemple.fr'],
  ['seo_title','Titre Google de la page d\'accueil','text',''],
  ['seo_desc','Description Google de la page d\'accueil','textarea',''],
  ['og_image','Image de partage (réseaux sociaux)','image',''],
  ['head_code','Code de suivi (Google Analytics, etc.)','textarea',''],
 ],
]; }
function S($k){
  if(!isset($GLOBALS['_S'])){ $c=[]; foreach(setting_defs() as $g) foreach($g as $f) $c[$f[0]]=$f[3];
    foreach(db()->query("SELECT k,v FROM settings") as $r) $c[$r['k']]=$r['v']; $GLOBALS['_S']=$c; }
  return $GLOBALS['_S'][$k]??'';
}
function S_clear(){ unset($GLOBALS['_S']); }
function S_set($k,$v){ db()->prepare("REPLACE INTO settings(k,v) VALUES(?,?)")->execute([$k,$v]); S_clear(); }
function tel(){ $p=preg_replace('/[^\d+]/','',S('phone')); if(strlen($p)==10 && $p[0]=='0') $p='+33'.substr($p,1); return $p; }
function base(){ return rtrim(S('site_url'),'/'); }

// ---------- Nettoyage du HTML saisi dans l'éditeur ----------
function clean_html($h){
  $h=preg_replace('#<(script|style|iframe|object|embed|form|svg|math)\b.*?</\1>#is','',(string)$h);
  $h=strip_tags($h,'<p><br><strong><b><em><i><u><h2><h3><h4><ul><ol><li><a><img><blockquote><figure><figcaption><hr><table><thead><tbody><tr><th><td>');
  $h=preg_replace('/\s+on\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i','',$h);
  $h=preg_replace('/\s+(style|class|id|srcset)\s*=\s*("[^"]*"|\'[^\']*\')/i','',$h);
  $h=preg_replace('/(href|src)\s*=\s*(["\'])\s*(javascript|data|vbscript):[^"\']*\2/i','$1=$2#$2',$h);
  return trim($h);
}
function read_min($html){ $n=preg_match_all('/\S+/u',strip_tags((string)$html)); return max(1,(int)ceil($n/200)); }
function add_toc($html){ // ajoute des ancres aux h2 et renvoie [html, sommaire]
  $toc=[]; $html=preg_replace_callback('#<h2[^>]*>(.*?)</h2>#is',function($m) use(&$toc){ $t=trim(strip_tags($m[1])); $id=slugify($t); $toc[]=[$id,$t]; return '<h2 id="'.$id.'">'.$m[1].'</h2>'; },(string)$html);
  return [$html,$toc];
}

// ---------- Envoi d'images / vidéos ----------
function shrink_image($path,$ext,$max=2400){
  if(!function_exists('imagecreatetruecolor')) return;
  $i=@getimagesize($path); if(!$i||$i[0]<=$max) return; $src=null;
  if($ext==='jpg') $src=@imagecreatefromjpeg($path); elseif($ext==='png') $src=@imagecreatefrompng($path); elseif($ext==='webp'&&function_exists('imagecreatefromwebp')) $src=@imagecreatefromwebp($path);
  if(!$src) return; $w=$max; $h=(int)round($i[1]*$max/$i[0]); $dst=imagecreatetruecolor($w,$h);
  if($ext==='png'){ imagealphablending($dst,false); imagesavealpha($dst,true); }
  imagecopyresampled($dst,$src,0,0,0,0,$w,$h,$i[0],$i[1]);
  if($ext==='png') imagepng($dst,$path,6); elseif($ext==='webp') imagewebp($dst,$path,85); else imagejpeg($dst,$path,85);
}
function save_upload($f){ // retourne [chemin|null, erreur|null]
  if(!$f||!isset($f['error'])||$f['error']!==UPLOAD_ERR_OK) return [null,'L\'envoi a échoué (fichier trop lourd pour le serveur ?).'];
  $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION)); if($ext==='jpeg') $ext='jpg';
  if(in_array($ext,['jpg','png','webp','gif'])){ if(!@getimagesize($f['tmp_name'])) return [null,'Ce fichier n\'est pas une image valide.']; if($f['size']>15*1048576) return [null,'Image trop lourde (15 Mo maximum).']; }
  elseif(in_array($ext,['mp4','webm'])){ if($f['size']>80*1048576) return [null,'Vidéo trop lourde (80 Mo maximum).']; }
  else return [null,'Formats acceptés : jpg, png, webp, gif, mp4, webm.'];
  if(!is_dir(ROOT.'/uploads')) @mkdir(ROOT.'/uploads',0755,true);
  $name=date('Ymd').'-'.bin2hex(random_bytes(5)).'.'.$ext; $dest=ROOT.'/uploads/'.$name;
  if(!move_uploaded_file($f['tmp_name'],$dest)) return [null,'Impossible d\'écrire dans le dossier uploads (vérifiez les droits).'];
  if(in_array($ext,['jpg','png','webp'])) shrink_image($dest,$ext);
  $orig=preg_replace('/[^\p{L}\p{N}._ -]+/u','',$f['name']);
  db()->prepare("INSERT INTO media(path,name) VALUES(?,?)")->execute(['/uploads/'.$name,mb_substr($orig,0,120)]);
  return ['/uploads/'.$name,null];
}
