/* Maison et Solutions : effets et interactions (JavaScript simple, sans dépendance) */
(function () {
  'use strict';
  var d = document, de = d.documentElement, $ = function (s, r) { return (r || d).querySelector(s); }, $$ = function (s, r) { return [].slice.call((r || d).querySelectorAll(s)); };
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia && matchMedia('(hover:hover) and (pointer:fine)').matches;

  /* 1. Animation d'entrée (une seule fois par visite) */
  var intro = $('.intro');
  function ready() { de.classList.add('ready'); }
  if (de.classList.contains('ni') || reduce || !intro) { ready(); if (intro) intro.remove(); }
  else {
    try { sessionStorage.i = 1; } catch (e) {}
    setTimeout(function () { intro.classList.add('out'); ready(); setTimeout(function () { intro.remove(); }, 1000); }, 2300);
  }

  /* 2. Titres : découpage mot par mot */
  $$('[data-words], .hero h1').forEach(function (h) {
    if (h.querySelector('.wd')) return;
    var i = 0;
    (function walk(n) {
      [].slice.call(n.childNodes).forEach(function (c) {
        if (c.nodeType === 3) {
          var f = d.createDocumentFragment();
          c.textContent.split(/(\s+)/).forEach(function (t) {
            if (!t) return;
            if (/^\s+$/.test(t)) { f.appendChild(d.createTextNode(' ')); return; }
            var w = d.createElement('span'), s = d.createElement('span');
            w.className = 'wd'; s.textContent = t; s.style.setProperty('--i', i++); w.appendChild(s); f.appendChild(w);
          });
          n.replaceChild(f, c);
        } else if (c.nodeType === 1) walk(c);
      });
    })(h);
  });
  if (!$('.wd')) { /* rien */ }

  /* 3. En-tête, barre de progression, parallaxe */
  var hd = $('#hd'), pr = $('.progress'), pars = $$('[data-par]'), ticking = false;
  function onScroll() {
    var y = window.pageYOffset, h = de.scrollHeight - innerHeight;
    if (hd) hd.classList.toggle('sm', y > 40);
    if (pr) pr.style.setProperty('--sp', h > 0 ? Math.min(1, y / h) : 0);
    if (!reduce) pars.forEach(function (p) { if (y < innerHeight * 1.5) p.style.transform = 'translate3d(0,' + (y * parseFloat(p.dataset.par)) + 'px,0)'; });
    tl();
    ticking = false;
  }
  window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  function setHH() { if (hd) de.style.setProperty('--hh', ($('.top') ? $('.top').offsetHeight : 0) * 0 + hd.getBoundingClientRect().bottom + 'px'); }

  /* 4. Apparition au défilement + décalage des enfants */
  $$('[data-stag]').forEach(function (g) {
    $$('[data-r]', g).forEach(function (c, i) { if (c.parentNode === g || c.closest('[data-stag]') === g) c.style.setProperty('--d', Math.min(i, 8) * 0.09 + 's'); });
  });
  var targets = $$('[data-r], .sh');
  if (!('IntersectionObserver' in window) || reduce) targets.forEach(function (t) { t.classList.add('in'); });
  else {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.01, rootMargin: '0px 0px -6% 0px' });
    targets.forEach(function (t) { io.observe(t); });
  }

  /* 5. Compteurs */
  function count(el) {
    var to = parseFloat(el.dataset.to), pre = el.dataset.pre || '', suf = el.dataset.suf || '', t0 = null, dur = 1800;
    if (isNaN(to)) return;
    function f(t) {
      if (!t0) t0 = t; var p = Math.min(1, (t - t0) / dur), v = Math.round(to * (1 - Math.pow(1 - p, 4)));
      el.textContent = pre + v.toLocaleString('fr-FR') + suf; if (p < 1) requestAnimationFrame(f);
    }
    requestAnimationFrame(f);
  }
  var nums = $$('.num[data-to]');
  if ('IntersectionObserver' in window && !reduce) {
    var co = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { count(e.target); co.unobserve(e.target); } }); }, { threshold: 0.6 });
    nums.forEach(function (n) { co.observe(n); });
  }

  /* 6. Frise des étapes : la ligne se remplit */
  var tls = $$('.tl');
  function tl() {
    tls.forEach(function (l) {
      var r = l.getBoundingClientRect(), p = (innerHeight * 0.6 - r.top) / r.height;
      p = Math.max(0, Math.min(1, p)); l.style.setProperty('--p', p);
      $$('li', l).forEach(function (li) { var b = li.getBoundingClientRect(); li.classList.toggle('on', b.top < innerHeight * 0.62); });
    });
  }

  /* 7. Effets de souris : projecteur, inclinaison, bouton magnétique, poussière d'or */
  if (fine && !reduce) {
    var hero = $('.hero'), spot = $('.spot');
    if (hero && spot) hero.addEventListener('mousemove', function (e) {
      var r = hero.getBoundingClientRect(); spot.style.setProperty('--mx', (e.clientX - r.left) + 'px'); spot.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    $$('.nd, [data-tilt]').forEach(function (c) {
      c.addEventListener('mousemove', function (e) {
        var r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        c.style.setProperty('--ry', ((x - 0.5) * 6) + 'deg'); c.style.setProperty('--rx', ((0.5 - y) * 6) + 'deg');
        c.style.setProperty('--gx', (x * 100) + '%'); c.style.setProperty('--gy', (y * 100) + '%');
      });
      c.addEventListener('mouseleave', function () { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); });
    });
    $$('[data-mag]').forEach(function (b) {
      b.addEventListener('mousemove', function (e) {
        var r = b.getBoundingClientRect(); b.style.translate = ((e.clientX - r.left - r.width / 2) * 0.18) + 'px ' + ((e.clientY - r.top - r.height / 2) * 0.28) + 'px';
      });
      b.addEventListener('mouseleave', function () { b.style.translate = ''; });
    });
  }
  $$('canvas.dust').forEach(function (cv) {
    if (reduce) return;
    var x = cv.getContext('2d'), P = [], W, H, run = true, N = 46;
    function size() { W = cv.width = cv.offsetWidth; H = cv.height = cv.offsetHeight; }
    size(); window.addEventListener('resize', size);
    for (var i = 0; i < N; i++) P.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.6 + 0.4, s: Math.random() * 0.00018 + 0.00005, a: Math.random() * 0.6 + 0.2 });
    function loop() {
      if (run) {
        x.clearRect(0, 0, W, H);
        P.forEach(function (p) { p.y -= p.s * 16; p.x += Math.sin(p.y * 9) * 0.0003; if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
          x.beginPath(); x.fillStyle = 'rgba(222,184,120,' + p.a + ')'; x.arc(p.x * W, p.y * H, p.r, 0, 6.3); x.fill(); });
      }
      requestAnimationFrame(loop);
    }
    if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { run = es[0].isIntersecting; }).observe(cv);
    loop();
  });

  /* 8. Menu : grand menu des services + menu mobile */
  var dd = $('.dd'), ddt = $('.dd-t'), bg = $('#bg'), ct;
  function ddOpen(o) { if (!dd) return; dd.classList.toggle('open', o); ddt.setAttribute('aria-expanded', o); }
  if (dd) {
    ddt.addEventListener('click', function () { ddOpen(fine ? true : !dd.classList.contains('open')); });
    if (fine) {
      dd.addEventListener('mouseenter', function () { clearTimeout(ct); ddOpen(true); });
      dd.addEventListener('mouseleave', function () { ct = setTimeout(function () { ddOpen(false); }, 160); });
    }
    d.addEventListener('click', function (e) { if (!dd.contains(e.target)) ddOpen(false); });
  }
  if (bg) bg.addEventListener('click', function () {
    var o = !d.body.classList.contains('mn-open'); setHH(); d.body.classList.toggle('mn-open', o); bg.setAttribute('aria-expanded', o); d.body.classList.toggle('no-scroll', o);
  });
  $$('#mn a').forEach(function (a) { a.addEventListener('click', function () { d.body.classList.remove('mn-open', 'no-scroll'); }); });
  window.addEventListener('resize', setHH); setHH();

  /* 9. Fenêtres (devis, rappel) */
  var lastFocus = null;
  function openM(m) {
    if (!m) return; lastFocus = d.activeElement; m.hidden = false;
    requestAnimationFrame(function () { m.classList.add('open'); }); d.body.classList.add('no-scroll');
    var f = $('input:not([type=hidden]):not(.hp),select,textarea,button.btn', m); if (f) setTimeout(function () { f.focus({ preventScroll: true }); }, 250);
  }
  function closeM(m) {
    m.classList.remove('open'); d.body.classList.remove('no-scroll');
    setTimeout(function () { if (!m.classList.contains('open')) m.hidden = true; }, 400);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  d.addEventListener('click', function (e) {
    var t = e.target.closest('[data-modal]');
    if (t) { e.preventDefault(); d.body.classList.remove('mn-open'); openM($('#m-' + t.dataset.modal)); return; }
    var c = e.target.closest('[data-close]');
    if (c) { closeM(c.closest('.modal, .lb')); return; }
    if (e.target.classList && (e.target.classList.contains('modal') || e.target.id === 'lb')) closeM(e.target);
  });
  d.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { $$('.modal.open, .lb.open').forEach(closeM); ddOpen(false); }
    var lb = $('#lb.open'); if (lb) { if (e.key === 'ArrowRight') lbGo(1); if (e.key === 'ArrowLeft') lbGo(-1); }
  });

  /* 10. Formulaires : devis en 2 étapes, rappel, envoi sans rechargement */
  $$('form.qf, form[data-qf]').forEach(function (f) {
    var msg = $('.fmsg', f);
    $$('.chip input', f).forEach(function (r) { r.addEventListener('change', function () { var p = $('[data-proj]', f); if (p) p.textContent = '(' + r.value + ')'; }); });
    var nx = $('[data-next]', f), pv = $('[data-prev]', f);
    if (nx) nx.addEventListener('click', function () {
      var chosen = $('.chip input:checked', f);
      if (!chosen) { if (msg) { msg.className = 'fmsg ko'; msg.textContent = 'Choisissez un type de projet pour continuer.'; } return; }
      if (msg) msg.textContent = ''; f.classList.add('s2'); var i = $('.qs2 input:not([type=hidden]):not(.hp)', f); if (i) i.focus({ preventScroll: true });
    });
    if (pv) pv.addEventListener('click', function () { f.classList.remove('s2'); });
    $$('input[name=mode]', f).forEach(function (r) { r.addEventListener('change', function () { f.classList.toggle('later-on', r.value === 'Plus tard' && r.checked); }); });
    f.addEventListener('submit', function (e) {
      if (!window.fetch || !window.FormData) return;
      e.preventDefault();
      var b = $('button.btn:not([data-next]):not([data-prev])', f), old = b ? b.textContent : '';
      if (b) { b.disabled = true; b.textContent = 'Envoi...'; }
      var fd = new FormData(f), body = new URLSearchParams();
      fd.forEach(function (v, k) { if (typeof v === 'string') body.append(k, v); });
      if (!body.get('form-name')) body.set('form-name', f.getAttribute('name') || 'contact');
      fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
        .then(function (r) {
          if (!r.ok) throw new Error('http');
          if (!f.classList.contains('nl')) { location.href = '/merci.html'; return; }
          if (msg) { msg.className = 'fmsg ok'; msg.textContent = 'Merci, vous êtes inscrit(e).'; } f.reset();
        })
        .catch(function () { if (msg) { msg.className = 'fmsg ko'; msg.textContent = 'Envoi impossible pour le moment. Appelez-nous ou réessayez.'; } })
        .then(function () { if (b) { b.disabled = false; b.textContent = old; } });
    });
  });

  /* 11. FAQ en accordéon */
  $$('.fq button').forEach(function (b) {
    b.addEventListener('click', function () {
      var q = b.closest('.fq'), o = !q.classList.contains('open');
      $$('.fq.open', q.parentNode).forEach(function (x) { x.classList.remove('open'); $('button', x).setAttribute('aria-expanded', 'false'); });
      q.classList.toggle('open', o); b.setAttribute('aria-expanded', o);
    });
  });

  /* 12. Avis : défilement */
  $$('.rv').forEach(function (rv) {
    var nav = rv.nextElementSibling; if (!nav) return;
    function step(dir) { rv.scrollBy({ left: dir * (rv.firstElementChild ? rv.firstElementChild.offsetWidth + 22 : 400), behavior: reduce ? 'auto' : 'smooth' }); }
    var p = $('.rv-p', nav), x = $('.rv-x', nav); if (p) p.addEventListener('click', function () { step(-1); }); if (x) x.addEventListener('click', function () { step(1); });
  });

  /* 13. Réalisations : filtres, « voir plus », visionneuse avant/après */
  var pjs = $$('.pj'), cur = 0, vis = [];
  var fb = $$('[data-filter]'), more = $('#more-pj'), grid = $('.pjs'), per = grid ? parseInt(grid.dataset.more, 10) || 9 : 9, shown = per, flt = '*';
  function applyPj() {
    var n = 0, tot = 0;
    pjs.forEach(function (p) {
      var ok = flt === '*' || p.dataset.svc === flt; if (ok) tot++;
      var s = ok && n < shown; if (ok && s) n++; p.classList.toggle('hide', !s);
    });
    if (more) more.hidden = tot <= shown;
  }
  fb.forEach(function (b) { b.addEventListener('click', function () { fb.forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); flt = b.dataset.filter; shown = per; applyPj(); }); });
  if (more) more.addEventListener('click', function () { shown += per; applyPj(); });
  if (pjs.length) applyPj();

  var lb = $('#lb'), stage = lb && $('.lb-s', lb), cap = lb && $('.lb-c', lb);
  function lbShow() {
    var b = vis[cur]; if (!b) return; var src = b.dataset.src, bf = b.dataset.before;
    stage.innerHTML = '';
    if (!src) { var ph = d.createElement('div'); ph.className = 'ph'; stage.appendChild(ph); }
    else if (bf) {
      var w = d.createElement('div'); w.className = 'ba';
      w.innerHTML = '<img alt="Après" src="' + src.replace(/"/g, '&quot;') + '"><div class="bf"><img alt="Avant" src="' + bf.replace(/"/g, '&quot;') + '"></div><span class="hd"></span><em class="l1">Avant</em><em class="l2">Après</em>';
      stage.appendChild(w);
      function mv(ev) { var r = w.getBoundingClientRect(), x = (ev.touches ? ev.touches[0].clientX : ev.clientX) - r.left; w.style.setProperty('--bp', Math.max(0, Math.min(100, x / r.width * 100)) + '%'); }
      var drag = false;
      w.addEventListener('pointerdown', function (ev) { drag = true; mv(ev); });
      window.addEventListener('pointermove', function (ev) { if (drag) mv(ev); });
      window.addEventListener('pointerup', function () { drag = false; });
    } else { var im = d.createElement('img'); im.src = src; im.alt = b.dataset.cap || ''; stage.appendChild(im); }
    cap.textContent = (b.dataset.cap || '') + (b.dataset.txt ? ' : ' + b.dataset.txt : '');
  }
  function lbGo(s) { cur = (cur + s + vis.length) % vis.length; lbShow(); }
  d.addEventListener('click', function (e) {
    var b = e.target.closest('[data-lb]'); if (!b || !lb) return;
    vis = $$('.pj:not(.hide) [data-lb]'); cur = Math.max(0, vis.indexOf(b)); lbShow(); lb.hidden = false;
    requestAnimationFrame(function () { lb.classList.add('open'); }); d.body.classList.add('no-scroll');
  });
  if (lb) { $('.lb-p', lb).addEventListener('click', function () { lbGo(-1); }); $('.lb-x', lb).addEventListener('click', function () { lbGo(1); }); }

  /* 14. Blog : recherche et « voir plus » */
  var bs = $('#bsearch'), mb = $('#more-bl'), be = $('#bempty'), cards = $$('.posts .pc'), bshown = 9, q = '';
  function applyBl() {
    var n = 0, tot = 0;
    cards.forEach(function (c) {
      var ok = !q || (c.dataset.t || '').indexOf(q) > -1; if (ok) tot++;
      var s = ok && n < bshown; if (s) n++; c.classList.toggle('hide', !s);
    });
    if (mb) mb.hidden = tot <= bshown; if (be) be.hidden = tot > 0;
  }
  if (cards.length) {
    if (bs) bs.addEventListener('input', function () { q = bs.value.toLowerCase().trim(); bshown = 9; applyBl(); });
    if (mb) mb.addEventListener('click', function () { bshown += 9; applyBl(); });
    applyBl();
  }

  /* 15. Lien d'ancre doux (sommaire des articles) */
  $$('.toc a[href^="#"]').forEach(function (a) { a.addEventListener('click', function (e) { var t = $(a.getAttribute('href')); if (t) { e.preventDefault(); t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' }); } }); });

  onScroll();
})();
